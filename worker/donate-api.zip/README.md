# donate-api (Cloudflare Worker)

Backend của trang `/donate`: nhận webhook SePay, tạo mã đơn + QR, kiểm duyệt tên (bộ lọc nội bộ, không dùng AI) và lời nhắn (regex + Gemini, Workers AI dự phòng), đăng nhập YouTube, phát alert cho overlay OBS và cung cấp số liệu cho trang `/admin/donate/stats`.

Địa chỉ: `https://donate-api.git-api.workers.dev` (khớp trường `api` trong `donate/data.json` của web).

## Cấu trúc

```
donate-api/
├── index.js                          # toàn bộ mã Worker
├── wrangler.toml                     # cấu hình: tên Worker, D1, KV, AI, biến thường
├── package.json                      # cài wrangler + các lệnh npm
├── schema.sql                        # tạo bảng cho D1 TRỐNG (cài mới)
├── migrations/001_youtube_login.sql  # nâng cấp D1 ĐANG CÓ DỮ LIỆU (thêm đăng nhập YouTube)
├── .dev.vars.example                 # mẫu secret để chạy thử trên máy
└── .gitignore
```

## Deploy

Cần Node.js 18+ và tài khoản Cloudflare.

```bash
cd donate-api
npm install
npx wrangler login

# Secret (mỗi lệnh sẽ hỏi giá trị, không hiện ra màn hình)
npx wrangler secret put SEPAY_KEY        # chuỗi bí mật, dán đúng chuỗi này vào SePay (kiểu xác thực "API Key")
npx wrangler secret put OVERLAY_TOKEN    # chuỗi ngẫu nhiên, nằm trong link overlay OBS
npx wrangler secret put ADMIN_KEY        # khoá của trang /admin/donate và /admin/donate/stats
npx wrangler secret put GEMINI_API_KEY   # khoá API Gemini AI
npx wrangler secret put SESSION_KEY      # BẮT BUỘC cho đăng nhập YouTube: chuỗi ngẫu nhiên >= 32 byte (openssl rand -base64 48)
npx wrangler secret put YT_API_KEY       # tuỳ chọn: YouTube Data API v3, làm mới tên/avatar kênh mỗi 24 giờ

npm run deploy
```

Kiểm tra trước khi đăng: `npm run check`. Xem log khi đang chạy: `npm run tail`.

### Cơ sở dữ liệu D1

- **Cài mới (D1 trống):** `npx wrangler d1 execute donate-database --remote --file=schema.sql`
- **D1 đang có dữ liệu cũ:** `npx wrangler d1 execute donate-database --remote --file=migrations/001_youtube_login.sql` (chỉ chạy MỘT lần, xem chú thích trong file).

`database_name = "donate-database"` trong `wrangler.toml` là **tên của cơ sở dữ liệu D1** (không phải tên Worker) nên được giữ nguyên; D1 gắn vào Worker bằng `database_id`.

## Đổi tên Worker từ `shinju-donate` → `donate-api`

Tên mới tạo ra một Worker MỚI trên Cloudflare, D1 và KV vẫn là của cũ (cùng `database_id` / `id`) nên **dữ liệu donate không mất**. Cần làm:

1. `npm run deploy` Worker mới, rồi đặt lại **toàn bộ secret** ở trên (secret không tự chuyển từ Worker cũ). Nếu `SEPAY_KEY` từng lưu qua trang admin thì nó nằm trong KV và vẫn còn.
2. Đổi **Webhook URL** trong SePay thành `https://donate-api.git-api.workers.dev/webhook/sepay`.
3. Đẩy web mới lên GitHub (`donate/data.json` đã trỏ sang địa chỉ mới). Link overlay OBS không cần đổi vì overlay đọc địa chỉ từ `data.json`.
4. Thử donate 1 lần + gửi alert thử ở `/admin/donate`, thấy ổn thì **xoá Worker cũ `shinju-donate`** trong Cloudflare Dashboard.

## API

Công khai (CORS chỉ cho `ALLOW_ORIGIN`):

| Đường dẫn | Việc làm |
|---|---|
| `POST /webhook/sepay` | SePay báo có tiền vào (xác thực bằng `SEPAY_KEY`) |
| `POST /api/login` | Đổi access token YouTube lấy thẻ phiên 30 ngày (token bị bỏ ngay, không lưu) |
| `POST /api/create` | Tạo mã đơn + thông tin chuyển khoản |
| `GET /api/stats` | Top 10 + 10 donate gần nhất cho trang `/donate` (cache 60 giây) |
| `GET /api/alerts?t=OVERLAY_TOKEN&after=…` | Overlay OBS hỏi alert mới |

Admin — `POST`, JSON, header `Authorization: Bearer <ADMIN_KEY>`:

| Đường dẫn | Việc làm |
|---|---|
| `/admin/secrets` | Xem / lưu `SEPAY_KEY` (lưu trong KV) |
| `/admin/test` | Gửi alert thử lên OBS |
| `/admin/summary` | Số lượt + số tiền theo 24 giờ / 7 ngày / 1 năm / toàn bộ |
| `/admin/donations` | Danh sách donate đã nhận. Body: `{ "q": "", "sort": "new", "limit": 30, "offset": 0 }` |

`/admin/donations`:

- `q` — tìm trong tin nhắn, mã đơn, tên và số tiền (`50000`, `50.000`, `50k`). Không phân biệt hoa/thường/dấu/khoảng trắng; số tiền khớp chính xác. Quét tối đa 20.000 donate mới nhất.
- `sort` — `new` (mới nhất, mặc định) · `amount_desc` (cao → thấp) · `amount_asc` (thấp → cao). Áp dụng cho cả khi có và không có `q`.
- `limit` 1–100 (mặc định 30), `offset` để phân trang.
- Trả về `{ total, items, hasMore }`; mỗi item có `name, handle, avatar, verified, amount, msg, msgHidden, code, noCode, paid`. `noCode = true` là khoản chuyển khoản không kèm mã đơn.

Chỉ tính donate đã nhận tiền (`status = 'paid'`); alert thử không bị tính.

## Kiểm duyệt tin nhắn & thời điểm phát alert

Cột `msg_ok` của bảng `donations`: `0` = ẩn · `1` = đã duyệt · `2` = **đang chờ AI**.

0. **Tên hiển thị** (tên kênh YouTube, @handle, tên khách) được kiểm ngay trong Worker bằng `maskName()`: không gọi Gemini/Workers AI, không tốn quota, tức thì. Phần vi phạm được che thành `#`, xem mục *Kiểm duyệt tên* bên dưới.
1. `/api/create`: bộ lọc regex chặn ngay từ tục. AI (Gemini trước, Workers AI dự phòng) chỉ được hỏi cho **tin nhắn**, sau khi số tiền/tên/giới hạn tần suất đã hợp lệ, chờ tối đa 8 giây — chưa xong/lỗi thì vẫn tạo mã, tin ở trạng thái `2` và AI chạy tiếp ở nền (tự thử lại tối đa 2 lần, có model dự phòng; AI lỗi liên tiếp thì tạm nghỉ 45 giây để alert không bị kẹt).
2. `/webhook/sepay`: khi tiền về mà tin vẫn là `2` thì kiểm duyệt lại ngay ở nền.
3. `/api/alerts`: alert có lời nhắn ở trạng thái `2` bị **giữ lại**, chưa phát (các alert sau nó cũng chờ để giữ đúng thứ tự, con trỏ không bị đẩy qua). Chốt xong mới phát. Quá 12 giây (`HOLD_MS`) mà AI vẫn chưa xong thì phát **không kèm lời nhắn** và chốt `0`.
4. Chỉ tin `msg_ok = 1` mới hiện ra ngoài (overlay, `/api/stats`).

### Kiểm duyệt tên

`maskName()` trong `index.js` chạy đồng bộ, không gọi mạng và **không chặn** donate: phần vi phạm được che thành một dấu `#` (`lô cặc` → `lô #`; nhiều từ vi phạm liền nhau gộp thành một `#`). Áp dụng cho tên kênh YouTube, @handle và tên khách; trang top/gần đây và overlay hiện tên đã che.

Các lớp: regex tiếng Việt cũ → chuẩn hoá chống lách luật (bỏ dấu, ký tự tàng hình, chữ Cyrillic giống Latin, leet `d1t m3` / `sh!t`, kéo dài chữ `fuuuck`, tách chữ `d i t m e`) → so khớp **theo từ** để không che nhầm tên như `Scunthorpe`, `Edit Me`, `Ishitani`. Tên khách có dãy ≥ 9 chữ số (số điện thoại) cũng bị che. Nếu tên kênh YouTube bị che hết (chỉ còn `#`) thì dùng @handle thay thế. Việc chặn tên trùng kênh YouTube đã đăng nhập (chống mạo danh) vẫn giữ nguyên.

Thêm từ cấm không cần deploy lại: sửa `donate/data.json` thêm `"blockWords": ["tu cam 1", "tu cam 2"]` (không phân biệt hoa/thường/dấu, tối thiểu 3 ký tự). Danh sách mặc định nằm ở `NAME_SUB` / `NAME_WORD` / `NAME_PHRASE` trong `index.js`.

Thử nhanh: `POST /admin/modtest` với `{ "name": "lô cặc" }` → `{ verdict: "MASKED", masked: "lô #", reasons: [...] }` (thêm `"guest": false` để bỏ qua luật số điện thoại).

Chẩn đoán AI (tin nhắn): `POST /admin/modtest` với `{ "msg": "hello" }` (thêm `"model": "@cf/google/gemma-3-12b-it"` để thử đúng 1 model) (header `Authorization: Bearer <ADMIN_KEY>`) trả về `verdict` (`OK` / `BAD` / `ERROR`), model, thời gian và lỗi cụ thể. `POST /admin/summary` có thêm `aiLastError` (lỗi AI gần nhất trong 7 ngày). Có thể đổi model chính bằng biến `AI_MODEL` trong `[vars]` của `wrangler.toml`. Không cần chạy migration D1.

## Biến cấu hình (`wrangler.toml`)

| Biến | Ý nghĩa |
|---|---|
| `ALLOW_ORIGIN` | Địa chỉ web được gọi API, không có `/` ở cuối |
| `CONFIG_URL` | `donate/data.json` trên GitHub Pages; Worker đọc cấu hình (mức tối thiểu, mẫu nội dung, ngân hàng…) từ đây, cache 60 giây |
| `GEMINI_API_KEY` | (secret, nên có) khóa Gemini từ https://aistudio.google.com/apikey. Có khóa thì Gemini được hỏi trước, Workers AI làm dự phòng. Đặt bằng `npx wrangler secret put GEMINI_API_KEY`, đừng ghi vào code/git |
| `GEMINI_MODELS` | (tuỳ chọn) model Gemini cách nhau bằng dấu phẩy, xếp theo ưu tiên. Mặc định: gemini-3.5-flash-lite, gemini-3.1-flash-lite, gemini-2.5-flash (2.5 có thể báo 404 với tài khoản mới) |
| `AI_MODELS` | (tuỳ chọn) danh sách model Workers AI dự phòng cho **tin nhắn**, cách nhau bằng dấu phẩy, xếp theo ưu tiên; model lỗi bị bỏ qua 2 phút. Mặc định chỉ 1 model: llama-3.1-8b (Workers AI khá chậm nên chỉ chạy khi Gemini lỗi) |
| `AI_MODEL` | (tuỳ chọn, cách cũ) 1 model được đưa lên đầu danh sách |
| `blockWords` (trong `data.json`) | (tuỳ chọn) mảng từ cấm bổ sung cho **tên**, xem *Kiểm duyệt tên* |
| `GOOGLE_CLIENT_ID` | OAuth Client ID đăng nhập YouTube (không bí mật); phải trùng `googleClientId` trong `data.json` |
