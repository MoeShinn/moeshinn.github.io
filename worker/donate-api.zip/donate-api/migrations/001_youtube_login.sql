-- Migration 001: đăng nhập YouTube cho trang donate.
-- Chạy cho D1 ĐANG CÓ DỮ LIỆU (donation cũ giữ nguyên, yt_id rỗng = khách):
--   wrangler d1 execute shinju-donate --remote --file=migrations/001_youtube_login.sql
--
-- LƯU Ý: dòng ALTER TABLE ... ADD COLUMN KHÔNG idempotent — chỉ chạy file này MỘT lần.
-- Nếu chạy lần 2 sẽ báo "duplicate column name: yt_id"; khi đó các lệnh phía sau (nếu chưa chạy) hãy chạy tay từng dòng.
-- Cài mới hoàn toàn (D1 trống) thì KHÔNG cần file này, dùng schema.sql.

CREATE TABLE IF NOT EXISTS yt_users(
 yt_id TEXT PRIMARY KEY, title TEXT NOT NULL DEFAULT '', handle TEXT DEFAULT '', avatar TEXT DEFAULT '', updated INTEGER DEFAULT 0);

ALTER TABLE donations ADD COLUMN yt_id TEXT DEFAULT '';

CREATE INDEX IF NOT EXISTS i_yt ON donations(yt_id, status);
