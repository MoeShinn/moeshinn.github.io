-- Schema cho CÀI MỚI (D1 trống). D1 đang có dữ liệu thì chạy migrations/001_youtube_login.sql thay vì file này.
CREATE TABLE IF NOT EXISTS donations(
 id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, name TEXT, msg TEXT DEFAULT '', msg_ok INTEGER DEFAULT 0,
 amount INTEGER DEFAULT 0, txn TEXT UNIQUE, status TEXT DEFAULT 'pending', audio TEXT DEFAULT '', created INTEGER, paid INTEGER,
 yt_id TEXT DEFAULT '');  -- ID kênh YouTube (lấy từ thẻ phiên đã ký, không tin client); rỗng = khách
CREATE TABLE IF NOT EXISTS yt_users(
 yt_id TEXT PRIMARY KEY, title TEXT NOT NULL DEFAULT '', handle TEXT DEFAULT '', avatar TEXT DEFAULT '', updated INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS i_paid ON donations(status,id);
CREATE INDEX IF NOT EXISTS i_yt ON donations(yt_id, status);
