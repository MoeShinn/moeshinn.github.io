// donate-api — Worker donate: SePay webhook + tạo mã + kiểm duyệt (bộ lọc tiếng Việt + AI) + alert cho overlay.
// Giọng đọc (Google TTS → speechSynthesis) chạy ngay trong overlay, Worker KHÔNG còn gọi TTS và không cần FPT_KEY.
// Cấu hình (min, nameMax, msgMax, template, ai, bank…) đọc trực tiếp từ donate/data.json trên GitHub Pages
// → sửa trong /admin/donate rồi "Lưu lên GitHub" là xong, không cần đẩy setting lên Cloudflare nữa.
// Secret cần đặt: SEPAY_KEY, OVERLAY_TOKEN, ADMIN_KEY, SESSION_KEY (bắt buộc cho đăng nhập YouTube), YT_API_KEY (tuỳ chọn: làm mới tên/avatar kênh)
// Biến thường (wrangler.toml [vars]): ALLOW_ORIGIN, CONFIG_URL, GOOGLE_CLIENT_ID
// Endpoint admin (Authorization: Bearer ADMIN_KEY, POST JSON): /admin/secrets, /admin/test, /admin/summary, /admin/donations — hai cái sau phục vụ trang /admin/donate/stats.
// Đăng nhập YouTube: trình duyệt lấy access_token (OAuth token client) → POST /api/login → Worker hỏi Google token có đúng ứng dụng/quyền không,
// lấy ID/tên/@/avatar kênh, VỨT token ngay (không lưu D1/KV/log) rồi trả "thẻ phiên" tự ký HMAC (30 ngày).
// /api/create lấy yt_id TỪ THẺ này, không bao giờ tin ID/tên do client gửi.
const J = (o, s = 200, h = {}) => new Response(JSON.stringify(o), { status: s, headers: { "Content-Type": "application/json", ...h } });
const clean = (s, n) => String(s ?? "").normalize("NFC").replace(/[§\u0000-\u001f<>]/g, "").replace(/\s+/g, " ").trim().slice(0, n);
const DEF = { min: 10000, nameMax: 24, msgMax: 120, template: "DONATE {ORDER CODE}", ai: true, bank: { id: "", name: "", acc: "", holder: "" } };
const sec = async (env, k) => (await env.KV.get("sec:" + k)) || env[k] || ""; // key đặt trong admin (KV) ưu tiên hơn secret wrangler

// ---- Cấu hình: data.json (GitHub Pages) → bản nhớ gần nhất → KV cũ → mặc định ----
let memCfg = null, memAt = 0;
async function cfgOf(env) {
  const now = Date.now();
  if (memCfg && now - memAt < 60000) return memCfg;
  let raw = null;
  try {
    const url = env.CONFIG_URL || (env.ALLOW_ORIGIN + "/donate/data.json");
    const r = await fetch(url, { cf: { cacheTtl: 60, cacheEverything: true } });
    if (r.ok) raw = await r.json();
  } catch {}
  if (!raw) raw = memCfg || (await env.KV.get("settings", "json").catch(() => null)) || {};
  const n = (v, d) => (Number.isFinite(+v) && +v > 0 ? Math.round(+v) : d);
  const tpl = typeof raw.template === "string" && raw.template.includes("{ORDER CODE}") ? raw.template : DEF.template; // bắt buộc có {ORDER CODE}
  memCfg = { min: n(raw.min, DEF.min), nameMax: n(raw.nameMax, DEF.nameMax), msgMax: n(raw.msgMax, DEF.msgMax), template: tpl,
    ai: raw.ai !== false, bank: { ...DEF.bank, ...(raw.bank || {}) } };
  memAt = now; return memCfg;
}

// Regex nhận mã đơn từ nội dung chuyển khoản. Ngân hàng hay xoá khoảng trắng / thêm tiền tố → cho phép \s* và tìm ở bất cứ đâu.
function codeRegex(tpl) {
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").trim().replace(/\s+/g, "\\s*");
  const [a, b = ""] = tpl.split("{ORDER CODE}");
  return new RegExp(esc(a) + "\\s*([A-Z0-9]{6})" + (b.trim() ? "\\s*" + esc(b) : ""), "i");
}

// ---- Kiểm duyệt ----
// Lớp 1: bộ lọc nhanh cho tiếng Việt (chữ có dấu / viết tắt hay gặp). Sửa danh sách tuỳ ý.
const BAD_VI = [
  /đ[ịi]t|đ[ụu]\s*(má|mẹ|con)|địt\s*mẹ|đ[ũu]\s*má/i, /cặc|lồn|buồi|bú\s*(cu|lol)|\bcu\s*to\b/i, /(?<![\p{L}])đĩ(?![\p{L}])|(?<![\p{L}])cave(?![\p{L}])|rửa\s*đít/iu, /(?<![\p{L}])(dit|du|đu)\s*(me|má|ma|con|bo|may|nhau)(?![\p{L}])/iu,
  /(?<![\p{L}\p{N}])(dm|đm|dmm|đmm|dcm|dcmm|đcm|vcl|vkl|clgt|cl|đjt|đ\.m)(?![\p{L}\p{N}])/iu,
  /thằng\s*chó|óc\s*chó|súc\s*vật|chó\s*chết|mẹ\s*mày|đồ\s*(khốn|điên|ngu)|thằng\s*(ngu|khốn)|con\s*(ngu|điên)/i,
  /https?:\/\/|www\.|\.(com|net|vn|me|gg|xyz|top|site|club)\b|t\.me\/|zalo|telegram|bit\.ly/i,        // link / quảng cáo
  /(giết|chém|bắn|đâm)\s*(chết|mày|nó|người)/i,
];
const spaced = (s) => s.replace(/[\s._\-*]+/g, "").toLowerCase(); // chống "đ i t", "d.m"
async function moderate(env, msg) { // true = ổn, false = vi phạm, null = AI lỗi/không chắc
  if (BAD_VI.some((r) => r.test(msg)) || /địt|lồn|cặc|buồi/i.test(spaced(msg))) return false;
  try {
    const r = await env.AI.run("@cf/meta/llama-3.1-8b-instruct", { max_tokens: 4, messages: [
      { role: "system", content: "Bạn kiểm duyệt tin nhắn donate tiếng Việt cho livestream YouTube. Trả lời đúng MỘT từ: BAD nếu tin có tục tĩu (kể cả viết tắt, bỏ dấu, viết cách chữ), xúc phạm, kỳ thị vùng miền/tôn giáo/chủng tộc/giới tính, chính trị (bất kể quốc gia), 18+, link/quảng cáo, kêu gọi bạo lực; ngược lại trả lời OK. Lời chúc, khen, cảm ơn, đùa vui bình thường là OK." },
      { role: "user", content: msg }] });
    const t = String(r.response || "");
    return /BAD/i.test(t) ? false : /OK/i.test(t) ? true : null;
  } catch { return null; }
}

// ---- Đăng nhập YouTube: thẻ phiên + kiểm tra token + giới hạn tần suất ----
const SESSION_DAYS = 30, YT_SCOPE = "https://www.googleapis.com/auth/youtube.readonly", YT_ID = /^UC[\w-]{22}$/;
const TE = new TextEncoder();
const b64u = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const unb64u = (s) => { s = String(s); return Uint8Array.from(atob(s.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - (s.length % 4)) % 4)), (c) => c.charCodeAt(0)); };
const hmacKey = (secret, use) => crypto.subtle.importKey("raw", TE.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, [use]);
const hasSessionKey = (env) => typeof env.SESSION_KEY === "string" && env.SESSION_KEY.length >= 16;
// Thẻ: base64url(payload) + "." + base64url(HMAC-SHA256(payload)); payload = { yt, exp (giây) }
async function signSession(env, yt) {
  const exp = Math.floor(Date.now() / 1000) + SESSION_DAYS * 86400, p = b64u(TE.encode(JSON.stringify({ yt, exp })));
  return { token: p + "." + b64u(await crypto.subtle.sign("HMAC", await hmacKey(env.SESSION_KEY, "sign"), TE.encode(p))), exp };
}
// Trả yt_id nếu thẻ đúng chữ ký (crypto.subtle.verify so sánh thời gian cố định) và chưa hết hạn; ngược lại null.
async function verifySession(env, token) {
  try {
    if (!hasSessionKey(env) || typeof token !== "string" || token.length > 600) return null;
    const parts = token.split("."); if (parts.length !== 2 || !parts[0] || !parts[1]) return null;
    if (!(await crypto.subtle.verify("HMAC", await hmacKey(env.SESSION_KEY, "verify"), unb64u(parts[1]), TE.encode(parts[0])))) return null;
    const d = JSON.parse(new TextDecoder().decode(unb64u(parts[0])));
    if (!d || typeof d.yt !== "string" || !YT_ID.test(d.yt) || !Number.isFinite(d.exp) || d.exp * 1000 <= Date.now()) return null;
    return d.yt;
  } catch { return null; }
}
const bearer = (req) => { const m = /^Bearer\s+(\S+)$/i.exec(req.headers.get("Authorization") || ""); return m ? m[1] : ""; };
// Avatar chỉ nhận https + host của Google/YouTube (không cho nhét URL lạ vào trang)
const okAvatar = (u) => { try { const x = new URL(u); return x.protocol === "https:" && /(^|\.)(ggpht\.com|googleusercontent\.com|ytimg\.com)$/i.test(x.hostname) ? x.href.slice(0, 500) : ""; } catch { return ""; } };
const pickAvatar = (th) => okAvatar(((th && (th.medium || th.high || th.default || th.standard)) || {}).url || "");
const okHandle = (h) => { try { h = decodeURIComponent(String(h || "")); } catch { h = String(h || ""); } return /^@[\p{L}\p{N}._\-·]{1,60}$/u.test(h) ? h : ""; };
// Gộp dấu / hoa thường / ký tự phân cách để so tên chống mạo danh: "Shinju", "shínju", "@ShinJu" → "shinju"
const fold = (s) => String(s ?? "").normalize("NFD").replace(/\p{M}/gu, "").replace(/đ/gi, "d").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "");
let ytNames = null, ytNamesAt = 0;
async function ytNameSet(env) {
  if (ytNames && Date.now() - ytNamesAt < 60000) return ytNames;
  const { results } = await env.DB.prepare("SELECT title,handle FROM yt_users LIMIT 20000").all();
  const s = new Set(); for (const r of results) { const a = fold(r.title), b = fold(r.handle); if (a) s.add(a); if (b) s.add(b); }
  ytNames = s; ytNamesAt = Date.now(); return s;
}
// Giới hạn tần suất bằng KV: tối đa `max` lần / phút / IP (KV không nguyên tử → rào chắn thô, đủ chống dội)
async function rateLimit(env, req, name, max) {
  const ip = req.headers.get("CF-Connecting-IP") || "?", k = `rl:${name}:${ip}:${Math.floor(Date.now() / 60000)}`;
  const n = +(await env.KV.get(k).catch(() => 0)) || 0; if (n >= max) return false;
  await env.KV.put(k, String(n + 1), { expirationTtl: 120 }).catch(() => {}); return true;
}
// Tên hiện công khai (lịch sử/top): lọc nhanh bằng regex đồng bộ để tên/@handle tục tĩu không lọt lên trang
const safeShow = (s) => (s && !(BAD_VI.some((r) => r.test(s)) || /địt|lồn|cặc|buồi/i.test(spaced(s))) ? s : "Người dùng YouTube");
// Làm mới tên/@/avatar kênh bằng YT_API_KEY (tuỳ chọn; không có key thì bỏ qua êm). Tối đa 1 lần/giờ, mỗi lần ≤ 50 kênh quá 24 giờ chưa cập nhật.
async function refreshYt(env) {
  try {
    const key = await sec(env, "YT_API_KEY"); if (!key) return;
    const now = Date.now(); if (now - (+(await env.KV.get("ytref:last")) || 0) < 3600000) return;
    await env.KV.put("ytref:last", String(now));
    const { results } = await env.DB.prepare("SELECT yt_id FROM yt_users WHERE updated<? ORDER BY updated LIMIT 50").bind(now - 86400000).all();
    if (!results.length) return;
    const ids = results.map((r) => r.yt_id), r = await fetch("https://www.googleapis.com/youtube/v3/channels?part=snippet&maxResults=50&id=" + ids.join(",") + "&key=" + encodeURIComponent(key));
    if (!r.ok) return;
    const items = (await r.json()).items || [], st = [];
    for (const c of items) {
      if (!YT_ID.test(c.id || "")) continue; const s = c.snippet || {};
      st.push(env.DB.prepare("UPDATE yt_users SET title=?,handle=?,avatar=?,updated=? WHERE yt_id=?").bind(clean(s.title, 100) || "Kênh YouTube", okHandle(s.customUrl), pickAvatar(s.thumbnails), now, c.id));
    }
    const got = new Set(items.map((c) => c.id)); // kênh không còn trả về (xoá/ẩn): chỉ đánh dấu đã kiểm tra để hàng đợi không bị kẹt
    for (const id of ids) if (!got.has(id)) st.push(env.DB.prepare("UPDATE yt_users SET updated=? WHERE yt_id=?").bind(now, id));
    if (st.length) await env.DB.batch(st);
    ytNamesAt = 0;
  } catch {}
}

// ---- Admin: xác thực + thống kê (chỉ đọc, dành cho trang /admin/donate/stats) ----
// So khớp thời gian cố định; ADMIN_KEY chưa đặt thì từ chối hẳn (tránh chuỗi "Bearer undefined" lọt qua).
const safeEq = (a, b) => { a = TE.encode(a); b = TE.encode(b); if (a.length !== b.length) return false; let d = 0; for (let i = 0; i < a.length; i++) d |= a[i] ^ b[i]; return d === 0; };
const isAdmin = (req, env) => !!env.ADMIN_KEY && safeEq(req.headers.get("Authorization") || "", "Bearer " + env.ADMIN_KEY);

const DAY = 86400000, MAX_SCAN = 20000, PAGE_MAX = 100;
const ORDER = { // whitelist: giá trị client gửi chỉ chọn khoá, không bao giờ nối vào SQL
  new: "d.paid DESC, d.id DESC",
  amount_desc: "d.amount DESC, d.paid DESC, d.id DESC",
  amount_asc: "d.amount ASC, d.paid DESC, d.id DESC",
};
const ROW_SQL = "SELECT d.id,d.code,d.name,d.msg,d.msg_ok,d.amount,d.paid,d.yt_id,u.title,u.handle,u.avatar FROM donations d LEFT JOIN yt_users u ON u.yt_id=d.yt_id AND d.yt_id!='' WHERE d.status='paid'";
const REAL_CODE = /^[A-HJ-NP-Z2-9]{6}$/; // mã đơn thật do /api/create sinh; chuyển khoản không mã thì code = "X" + id giao dịch

// Số tiền người dùng gõ: "50000", "50.000", "50,000đ", "50k" → số nguyên; không phải số tiền → null
function parseAmount(q) {
  const s = String(q).toLowerCase().replace(/\s+/g, "").replace(/(đ|d|vnd|vnđ)$/, "");
  if (/^\d{1,3}([.,]\d{3})+$/.test(s)) return +s.replace(/[.,]/g, "");
  if (/^\d+k$/.test(s)) return +s.slice(0, -1) * 1000;
  return /^\d+$/.test(s) ? +s : null;
}
// Tìm không phân biệt hoa/thường, dấu, khoảng trắng ("chuc mung" khớp "Chúc mừng"); số tiền khớp chính xác
function matcher(q) {
  const needle = fold(q), amt = parseAmount(q);
  return (r) => (amt !== null && r.amount === amt) || (!!needle && [r.code, r.name, r.title, r.handle, r.msg].some((f) => fold(f).includes(needle)));
}
const toItem = (r) => {
  const verified = !!r.yt_id && r.title != null;
  return { id: r.id, name: verified ? r.title || r.handle || "Kênh YouTube" : r.name, handle: verified ? r.handle || "" : "", avatar: verified ? r.avatar || "" : "", verified,
    amount: r.amount, msg: r.msg || "", msgHidden: !!r.msg && !r.msg_ok, code: r.code, noCode: !REAL_CODE.test(r.code || ""), paid: r.paid };
};
const intIn = (v, d, min, max) => Math.min(max, Math.max(min, Number.isFinite(+v) ? Math.floor(+v) : d));

// Số lượt + số tiền theo mốc 24 giờ / 7 ngày / 1 năm / toàn bộ (chỉ tính donate đã nhận tiền, không tính alert thử)
async function adminSummary(db) {
  const now = Date.now(), t = [now - DAY, now - 7 * DAY, now - 365 * DAY];
  const r = await db.prepare("SELECT COUNT(*) c,COALESCE(SUM(amount),0) s,"
    + "COUNT(CASE WHEN paid>=? THEN 1 END) c1,COALESCE(SUM(CASE WHEN paid>=? THEN amount END),0) s1,"
    + "COUNT(CASE WHEN paid>=? THEN 1 END) c7,COALESCE(SUM(CASE WHEN paid>=? THEN amount END),0) s7,"
    + "COUNT(CASE WHEN paid>=? THEN 1 END) cy,COALESCE(SUM(CASE WHEN paid>=? THEN amount END),0) sy FROM donations WHERE status='paid'")
    .bind(t[0], t[0], t[1], t[1], t[2], t[2]).first();
  return { now, ranges: { "24h": { count: r.c1, amount: r.s1 }, "7d": { count: r.c7, amount: r.s7 }, "1y": { count: r.cy, amount: r.sy }, all: { count: r.c, amount: r.s } } };
}

// Danh sách donate đã nhận: có tìm kiếm (tin nhắn / mã đơn / số tiền / tên) + sắp xếp + phân trang
async function adminDonations(db, b) {
  const q = clean(b.q, 100), order = ORDER[b.sort] || ORDER.new, limit = intIn(b.limit, 30, 1, PAGE_MAX), offset = intIn(b.offset, 0, 0, 1e7);
  if (!q) { // không tìm kiếm: để SQL lo phân trang
    const total = (await db.prepare("SELECT COUNT(*) c FROM donations d WHERE d.status='paid'").first()).c;
    const { results } = await db.prepare(`${ROW_SQL} ORDER BY ${order} LIMIT ? OFFSET ?`).bind(limit, offset).all();
    return { total, items: results.map(toItem), hasMore: offset + results.length < total };
  }
  // có tìm kiếm: lọc bằng JS để tìm được không dấu; thứ tự đã do SQL sắp sẵn nên chỉ cần lọc rồi cắt trang
  const { results } = await db.prepare(`${ROW_SQL} ORDER BY ${order} LIMIT ?`).bind(MAX_SCAN).all();
  const hit = results.filter(matcher(q)), page = hit.slice(offset, offset + limit);
  return { total: hit.length, items: page.map(toItem), hasMore: offset + page.length < hit.length };
}

async function cached(req, ctx, fn) {
  const c = caches.default, hit = await c.match(req); if (hit) return hit;
  const res = await fn(); res.headers.set("Cache-Control", "public, max-age=60"); ctx.waitUntil(c.put(req, res.clone())); return res;
}
export default {
  async fetch(req, env, ctx) {
    const u = new URL(req.url), p = u.pathname;
    const cors = { "Access-Control-Allow-Origin": env.ALLOW_ORIGIN, "Access-Control-Allow-Headers": "Content-Type,Authorization", "Access-Control-Allow-Methods": "GET,POST,OPTIONS" };
    if (req.method === "OPTIONS") return new Response(null, { headers: cors });
    const out = async () => { try { const r = await route(); for (const k in cors) r.headers.set(k, cors[k]); return r; } catch (e) { return J({ error: "Lỗi máy chủ" }, 500, cors); } };
    return out();
    async function route() {
      const db = env.DB;
      if (p === "/webhook/sepay" && req.method === "POST") {
        if (req.headers.get("Authorization") !== "Apikey " + await sec(env, "SEPAY_KEY")) return J({ error: "unauthorized" }, 401);
        const b = await req.json(); if (b.transferType !== "in") return J({ success: true });
        const cfg = await cfgOf(env), txn = String(b.id), amount = Math.round(+b.transferAmount || 0);
        if ((await db.prepare("SELECT id FROM donations WHERE txn=?").bind(txn).first())) return J({ success: true }); // chống trùng
        const m = String(b.content || "").match(codeRegex(cfg.template)), code = m && m[1].toUpperCase();
        const row = code && await db.prepare("SELECT * FROM donations WHERE code=? AND status='pending'").bind(code).first();
        const name = row ? row.name : "Ẩn danh", now = Date.now();
        // audio để trống: overlay tự đọc bằng Google TTS / speechSynthesis
        if (row) await db.prepare("UPDATE donations SET status='paid',amount=?,txn=?,audio='',paid=? WHERE id=?").bind(amount, txn, now, row.id).run();
        else await db.prepare("INSERT INTO donations(code,name,msg_ok,amount,txn,status,audio,created,paid) VALUES(?,?,0,?,?,'paid','',?,?)").bind("X" + txn, name, amount, txn, now, now).run();
        return J({ success: true });
      }
      if (p === "/api/login" && req.method === "POST") {
        if (!hasSessionKey(env) || !env.GOOGLE_CLIENT_ID) return J({ error: "Đăng nhập YouTube chưa được cấu hình trên máy chủ." }, 503);
        const og = req.headers.get("Origin"); if (og && og !== env.ALLOW_ORIGIN) return J({ error: "Nguồn gửi yêu cầu không hợp lệ." }, 403);
        if (!(await rateLimit(env, req, "login", 6))) return J({ error: "Bạn thử đăng nhập quá nhanh, vui lòng đợi một phút rồi thử lại." }, 429);
        const lb = await req.json().catch(() => null), tok = lb && lb.access_token;
        if (typeof tok !== "string" || !/^[A-Za-z0-9._~+\/-]{20,2048}$/.test(tok)) return J({ error: "Dữ liệu đăng nhập không hợp lệ." }, 400);
        // 1) Token phải cấp cho ĐÚNG ứng dụng này, có quyền youtube.readonly và chưa hết hạn
        let info = null;
        try { const r = await fetch("https://oauth2.googleapis.com/tokeninfo?access_token=" + encodeURIComponent(tok)); info = r.ok ? await r.json() : null; }
        catch { return J({ error: "Không kết nối được Google, vui lòng thử lại sau." }, 502); }
        const nowS = Math.floor(Date.now() / 1000), exp = Number(info && info.exp), ein = Number(info && info.expires_in);
        const live = (Number.isFinite(exp) || Number.isFinite(ein)) && (!Number.isFinite(exp) || exp > nowS) && (!Number.isFinite(ein) || ein > 0);
        const scopes = String((info && info.scope) || "").split(/\s+/);
        if (!info || ![info.aud, info.azp].includes(env.GOOGLE_CLIENT_ID) || !scopes.includes(YT_SCOPE) || !live) return J({ error: "Phiên Google không hợp lệ hoặc đã hết hạn, hãy đăng nhập lại." }, 401);
        // 2) Lấy kênh YouTube của chính người dùng. Từ đây token chỉ nằm trong biến cục bộ của yêu cầu này, không được ghi đi đâu cả.
        let ch = null;
        try {
          const r = await fetch("https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true", { headers: { Authorization: "Bearer " + tok } });
          if (r.status === 401) return J({ error: "Phiên Google không hợp lệ hoặc đã hết hạn, hãy đăng nhập lại." }, 401);
          if (!r.ok) return J({ error: r.status === 403 ? "Không đọc được thông tin kênh YouTube (máy chủ chưa bật YouTube Data API hoặc bạn chưa cấp quyền)." : "YouTube đang gặp lỗi, vui lòng thử lại sau." }, 502);
          ch = ((await r.json()).items || [])[0] || null;
        } catch { return J({ error: "Không kết nối được YouTube, vui lòng thử lại sau." }, 502); }
        if (!ch) return J({ error: "Tài khoản Google này chưa có kênh YouTube. Hãy tạo kênh YouTube rồi đăng nhập lại, hoặc donate với tư cách khách." }, 404);
        if (!YT_ID.test(ch.id || "")) return J({ error: "YouTube trả về dữ liệu kênh không hợp lệ." }, 502);
        const s = ch.snippet || {}, title = clean(s.title, 100) || "Kênh YouTube", handle = okHandle(s.customUrl), avatar = pickAvatar(s.thumbnails);
        await db.prepare("INSERT INTO yt_users(yt_id,title,handle,avatar,updated) VALUES(?,?,?,?,?) ON CONFLICT(yt_id) DO UPDATE SET title=excluded.title,handle=excluded.handle,avatar=excluded.avatar,updated=excluded.updated").bind(ch.id, title, handle, avatar, Date.now()).run();
        ytNamesAt = 0;
        const { token, exp: sexp } = await signSession(env, ch.id);
        return J({ token, exp: sexp, title, handle, avatar });
      }
      if (p === "/api/create" && req.method === "POST") {
        const cfg = await cfgOf(env), b = await req.json().catch(() => null), now = Date.now();
        if (!b || typeof b !== "object") return J({ error: "Dữ liệu không hợp lệ" }, 400);
        // Có thẻ phiên → danh tính lấy từ thẻ (yt_id) và bảng yt_users; BỎ QUA name do client gửi. Thẻ sai/hết hạn → 401 để trình duyệt đăng nhập lại (không âm thầm hạ xuống khách).
        let yt = "", u = null; const tk = bearer(req);
        if (tk) { yt = (await verifySession(env, tk)) || ""; u = yt && (await db.prepare("SELECT title,handle FROM yt_users WHERE yt_id=?").bind(yt).first()); if (!u) return J({ error: "Phiên đăng nhập đã hết hạn, hãy đăng nhập lại.", relogin: true }, 401); }
        let name = "Ẩn danh"; const msg = clean(b.msg, cfg.msgMax), amount = Math.round(+b.amount || 0);
        if (u) { const t1 = clean(u.title, 60), t2 = clean(u.handle, 60); name = t1 && (await moderate(env, t1)) !== false ? t1 : t2 && (await moderate(env, t2)) !== false ? t2 : "Ẩn danh"; } // tên kênh bị lọc → dùng @handle
        else name = clean(b.name, cfg.nameMax) || "Ẩn danh";
        if (amount < cfg.min || amount > 50000000) return J({ error: "Số tiền tối thiểu " + cfg.min.toLocaleString("vi-VN") + "đ" }, 400);
        const n = await db.prepare("SELECT COUNT(*) c FROM donations WHERE status='pending' AND created>?").bind(now - 60000).first();
        if (n.c > 40) return J({ error: "Hệ thống đang bận, thử lại sau ít phút" }, 429);
        if (!u && name !== "Ẩn danh") {
          if ((await ytNameSet(env)).has(fold(name))) return J({ error: "Tên này trùng với một kênh YouTube đã đăng nhập. Hãy đăng nhập bằng YouTube nếu đó là bạn, hoặc đổi tên khác nhé." }, 422); // chống mạo danh
          if (await moderate(env, name) === false) return J({ error: "Tên hiển thị có nội dung không phù hợp, bạn vui lòng đổi tên khác nhé." }, 422);
        }
        let ok = 1;
        if (msg && cfg.ai) { const v = await moderate(env, msg); if (v === false) return J({ error: "Tin nhắn có nội dung không phù hợp, bạn vui lòng sửa lại nhé." }, 422); if (v === null) ok = 0; }
        ctx.waitUntil(db.prepare("DELETE FROM donations WHERE status='pending' AND created<?").bind(now - 86400000).run());
        const A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; let code = "";
        for (const x of crypto.getRandomValues(new Uint8Array(6))) code += A[x % A.length];
        await db.prepare("INSERT INTO donations(code,name,msg,msg_ok,amount,created,yt_id) VALUES(?,?,?,?,?,?,?)").bind(code, name, msg, msg && ok ? 1 : 0, amount, now, yt).run();
        return J({ code, amount, content: cfg.template.replace("{ORDER CODE}", code), bank: cfg.bank, hidden: !!msg && !ok, name, verified: !!u });
      }
      if (p === "/api/alerts") {
        if (u.searchParams.get("t") !== env.OVERLAY_TOKEN) return J({ error: "forbidden" }, 403);
        // con trỏ là thời gian trả tiền (ms), không phải id: donate tạo mã trước nhưng trả sau vẫn không bị bỏ sót
        const after = +u.searchParams.get("after"), now = Date.now();
        if (!after && after !== 0 || u.searchParams.get("after") === "latest") return J({ last: now, items: [] });
        const from = Math.max(after, now - 120000); // OBS ẩn/tạm dừng rồi hiện lại: chỉ phát alert trong 2 phút gần nhất, không phát lại đồ cũ
        const { results } = await db.prepare("SELECT id,name,amount,msg,msg_ok,audio,paid,status,yt_id FROM donations WHERE status IN ('paid','test') AND paid>? ORDER BY paid,id LIMIT 10").bind(from).all();
        return J({ last: results.length ? results[results.length - 1].paid : after, items: results.map((r) => ({ id: r.id, name: r.name, amount: r.amount, msg: r.msg_ok ? r.msg : "", audio: r.audio, test: r.status === "test", verified: !!r.yt_id })) });
      }
      if (p === "/api/stats") return cached(req, ctx, async () => {
        const d = new Date(); const ms = new Date(d.getFullYear(), d.getMonth(), 1).getTime();
        const t = await db.prepare("SELECT COALESCE(SUM(amount),0) s,COUNT(*) c,COALESCE(SUM(CASE WHEN paid>=? THEN amount END),0) m FROM donations WHERE status='paid'").bind(ms).first();
        ctx.waitUntil(refreshYt(env)); // không có YT_API_KEY thì tự bỏ qua
        // Top 10: chỉ người đăng nhập YouTube, gom theo yt_id; tên/avatar lấy bản mới nhất ở yt_users (đổi tên kênh không mất lịch sử). Không trả yt_id ra ngoài.
        const top = (await db.prepare("SELECT u.title,u.handle,u.avatar,SUM(d.amount) s FROM donations d JOIN yt_users u ON u.yt_id=d.yt_id WHERE d.status='paid' AND d.yt_id!='' GROUP BY d.yt_id ORDER BY s DESC, MIN(d.paid) LIMIT 10").all()).results
          .map((r) => ({ name: safeShow(r.handle || r.title), avatar: r.avatar || "", amount: r.s, s: r.s, verified: true }));
        const recent = (await db.prepare("SELECT d.name,d.amount,d.paid,d.msg,d.msg_ok,d.yt_id,u.title,u.handle,u.avatar FROM donations d LEFT JOIN yt_users u ON u.yt_id=d.yt_id AND d.yt_id!='' WHERE d.status='paid' ORDER BY d.id DESC LIMIT 10").all()).results
          .map((r) => { const v = !!r.yt_id && r.title != null; return { name: v ? safeShow(r.handle || r.title) : r.name, avatar: v ? r.avatar || "" : "", verified: v, amount: r.amount, msg: r.msg_ok ? r.msg : "", paid: r.paid }; });
        return J({ total: t.s, count: t.c, month: t.m, top, recent });
      });
      if (p.startsWith("/admin/")) {
        if (!isAdmin(req, env)) return J({ error: "Sai Admin key" }, 401);
        const b = await req.json().catch(() => ({}));
        if (p === "/admin/summary") return J(await adminSummary(db));
        if (p === "/admin/donations") return J(await adminDonations(db, b));
        if (p === "/admin/secrets") { // chỉ còn SEPAY_KEY
          if (typeof b.set?.SEPAY_KEY === "string" && b.set.SEPAY_KEY.trim()) await env.KV.put("sec:SEPAY_KEY", b.set.SEPAY_KEY.trim());
          return J(b.get ? { SEPAY_KEY: await sec(env, "SEPAY_KEY") } : { ok: true });
        }
        // alert thử: audio = "mute" nghĩa là overlay không đọc giọng (alert thật luôn để trống = đọc theo cấu hình)
        if (p === "/admin/test") { const now = Date.now(), id = "T" + now + Math.floor(Math.random() * 1e4), msg = clean(b.msg, 200);
          await db.prepare("DELETE FROM donations WHERE status='test' AND created<?").bind(now - 3600000).run();
          await db.prepare("INSERT INTO donations(code,name,msg,msg_ok,amount,txn,status,audio,created,paid) VALUES(?,?,?,?,?,?,'test',?,?,?)").bind(id, clean(b.name, 24) || "Khách Test", msg, msg ? 1 : 0, Math.round(+b.amount || 0), id, b.audio === "mute" ? "mute" : "", now, now).run(); return J({ ok: true }); }
      }
      return J({ error: "not found" }, 404);
    }
  },
};
