// Worker donate: SePay webhook + tạo mã + kiểm duyệt (bộ lọc tiếng Việt + AI) + alert cho overlay.
// Giọng đọc (Google TTS → speechSynthesis) chạy ngay trong overlay, Worker KHÔNG còn gọi TTS và không cần FPT_KEY.
// Cấu hình (min, nameMax, msgMax, template, ai, bank…) đọc trực tiếp từ donate/data.json trên GitHub Pages
// → sửa trong /admin/donate rồi "Lưu lên GitHub" là xong, không cần đẩy setting lên Cloudflare nữa.
// Secret cần đặt: SEPAY_KEY, OVERLAY_TOKEN, ADMIN_KEY (wrangler secret put ...)
const J = (o, s = 200, h = {}) => new Response(JSON.stringify(o), { status: s, headers: { "Content-Type": "application/json", ...h } });
const clean = (s, n) => String(s ?? "").normalize("NFC").replace(/[§\u0000-\u001f<>]/g, "").replace(/\s+/g, " ").trim().slice(0, n);
const DEF = { min: 10000, nameMax: 24, msgMax: 120, template: "DONATE {ORDER CODE}", ai: true, bank: { id: "", name: "", acc: "", holder: "" } };
const sec = async (env, k) => (await env.KV.get("sec:" + k)) || env[k] || ""; // key đặt trong admin (KV) ưu tiên hơn secret wrangler

// ---- Cấu hình: data.json (GitHub Pages) → bản nhớ gần nhất → KV cũ → mặc định ----
let memCfg = null, memAt = 0;
async function cfgOf(env) {
  const now = Date.now();
  if (memCfg && now - memAt < 60000) return memCfg;
  let raw = null;
  try {
    const url = env.CONFIG_URL || (env.ALLOW_ORIGIN + "/donate/data.json");
    const r = await fetch(url, { cf: { cacheTtl: 60, cacheEverything: true } });
    if (r.ok) raw = await r.json();
  } catch {}
  if (!raw) raw = memCfg || (await env.KV.get("settings", "json").catch(() => null)) || {};
  const n = (v, d) => (Number.isFinite(+v) && +v > 0 ? Math.round(+v) : d);
  const tpl = typeof raw.template === "string" && raw.template.includes("{ORDER CODE}") ? raw.template : DEF.template; // bắt buộc có {ORDER CODE}
  memCfg = { min: n(raw.min, DEF.min), nameMax: n(raw.nameMax, DEF.nameMax), msgMax: n(raw.msgMax, DEF.msgMax), template: tpl,
    ai: raw.ai !== false, bank: { ...DEF.bank, ...(raw.bank || {}) } };
  memAt = now; return memCfg;
}

// Regex nhận mã đơn từ nội dung chuyển khoản. Ngân hàng hay xoá khoảng trắng / thêm tiền tố → cho phép \s* và tìm ở bất cứ đâu.
function codeRegex(tpl) {
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").trim().replace(/\s+/g, "\\s*");
  const [a, b = ""] = tpl.split("{ORDER CODE}");
  return new RegExp(esc(a) + "\\s*([A-Z0-9]{6})" + (b.trim() ? "\\s*" + esc(b) : ""), "i");
}

// ---- Kiểm duyệt ----
// Lớp 1: bộ lọc nhanh cho tiếng Việt (chữ có dấu / viết tắt hay gặp). Sửa danh sách tuỳ ý.
const BAD_VI = [
  /đ[ịi]t|đ[ụu]\s*(má|mẹ|con)|địt\s*mẹ|đ[ũu]\s*má/i, /cặc|lồn|buồi|bú\s*(cu|lol)|\bcu\s*to\b/i, /(?<![\p{L}])đĩ(?![\p{L}])|(?<![\p{L}])cave(?![\p{L}])|rửa\s*đít/iu, /(?<![\p{L}])(dit|du|đu)\s*(me|má|ma|con|bo|may|nhau)(?![\p{L}])/iu,
  /(?<![\p{L}\p{N}])(dm|đm|dmm|đmm|dcm|dcmm|đcm|vcl|vkl|clgt|cl|đjt|đ\.m)(?![\p{L}\p{N}])/iu,
  /thằng\s*chó|óc\s*chó|súc\s*vật|chó\s*chết|mẹ\s*mày|đồ\s*(khốn|điên|ngu)|thằng\s*(ngu|khốn)|con\s*(ngu|điên)/i,
  /https?:\/\/|www\.|\.(com|net|vn|me|gg|xyz|top|site|club)\b|t\.me\/|zalo|telegram|bit\.ly/i,        // link / quảng cáo
  /(giết|chém|bắn|đâm)\s*(chết|mày|nó|người)/i,
];
const spaced = (s) => s.replace(/[\s._\-*]+/g, "").toLowerCase(); // chống "đ i t", "d.m"
async function moderate(env, msg) { // true = ổn, false = vi phạm, null = AI lỗi/không chắc
  if (BAD_VI.some((r) => r.test(msg)) || /địt|lồn|cặc|buồi/i.test(spaced(msg))) return false;
  try {
    const r = await env.AI.run("@cf/meta/llama-3.1-8b-instruct", { max_tokens: 4, messages: [
      { role: "system", content: "Bạn kiểm duyệt tin nhắn donate tiếng Việt cho livestream YouTube. Trả lời đúng MỘT từ: BAD nếu tin có tục tĩu (kể cả viết tắt, bỏ dấu, viết cách chữ), xúc phạm, kỳ thị vùng miền/tôn giáo/chủng tộc/giới tính, chính trị (bất kể quốc gia), 18+, link/quảng cáo, kêu gọi bạo lực; ngược lại trả lời OK. Lời chúc, khen, cảm ơn, đùa vui bình thường là OK." },
      { role: "user", content: msg }] });
    const t = String(r.response || "");
    return /BAD/i.test(t) ? false : /OK/i.test(t) ? true : null;
  } catch { return null; }
}

async function cached(req, ctx, fn) {
  const c = caches.default, hit = await c.match(req); if (hit) return hit;
  const res = await fn(); res.headers.set("Cache-Control", "public, max-age=60"); ctx.waitUntil(c.put(req, res.clone())); return res;
}
export default {
  async fetch(req, env, ctx) {
    const u = new URL(req.url), p = u.pathname;
    const cors = { "Access-Control-Allow-Origin": env.ALLOW_ORIGIN, "Access-Control-Allow-Headers": "Content-Type,Authorization", "Access-Control-Allow-Methods": "GET,POST,OPTIONS" };
    if (req.method === "OPTIONS") return new Response(null, { headers: cors });
    const out = async () => { try { const r = await route(); for (const k in cors) r.headers.set(k, cors[k]); return r; } catch (e) { return J({ error: "Lỗi máy chủ" }, 500, cors); } };
    return out();
    async function route() {
      const db = env.DB;
      if (p === "/webhook/sepay" && req.method === "POST") {
        if (req.headers.get("Authorization") !== "Apikey " + await sec(env, "SEPAY_KEY")) return J({ error: "unauthorized" }, 401);
        const b = await req.json(); if (b.transferType !== "in") return J({ success: true });
        const cfg = await cfgOf(env), txn = String(b.id), amount = Math.round(+b.transferAmount || 0);
        if ((await db.prepare("SELECT id FROM donations WHERE txn=?").bind(txn).first())) return J({ success: true }); // chống trùng
        const m = String(b.content || "").match(codeRegex(cfg.template)), code = m && m[1].toUpperCase();
        const row = code && await db.prepare("SELECT * FROM donations WHERE code=? AND status='pending'").bind(code).first();
        const name = row ? row.name : "Ẩn danh", now = Date.now();
        // audio để trống: overlay tự đọc bằng Google TTS / speechSynthesis
        if (row) await db.prepare("UPDATE donations SET status='paid',amount=?,txn=?,audio='',paid=? WHERE id=?").bind(amount, txn, now, row.id).run();
        else await db.prepare("INSERT INTO donations(code,name,msg_ok,amount,txn,status,audio,created,paid) VALUES(?,?,0,?,?,'paid','',?,?)").bind("X" + txn, name, amount, txn, now, now).run();
        return J({ success: true });
      }
      if (p === "/api/create" && req.method === "POST") {
        const cfg = await cfgOf(env), b = await req.json(), now = Date.now();
        const name = clean(b.name, cfg.nameMax) || "Ẩn danh", msg = clean(b.msg, cfg.msgMax), amount = Math.round(+b.amount || 0);
        if (amount < cfg.min || amount > 50000000) return J({ error: "Số tiền tối thiểu " + cfg.min.toLocaleString("vi-VN") + "đ" }, 400);
        const n = await db.prepare("SELECT COUNT(*) c FROM donations WHERE status='pending' AND created>?").bind(now - 60000).first();
        if (n.c > 40) return J({ error: "Hệ thống đang bận, thử lại sau ít phút" }, 429);
        if (name !== "Ẩn danh" && await moderate(env, name) === false) return J({ error: "Tên hiển thị có nội dung không phù hợp, bạn vui lòng đổi tên khác nhé." }, 422);
        let ok = 1;
        if (msg && cfg.ai) { const v = await moderate(env, msg); if (v === false) return J({ error: "Tin nhắn có nội dung không phù hợp, bạn vui lòng sửa lại nhé." }, 422); if (v === null) ok = 0; }
        ctx.waitUntil(db.prepare("DELETE FROM donations WHERE status='pending' AND created<?").bind(now - 86400000).run());
        const A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; let code = "";
        for (const x of crypto.getRandomValues(new Uint8Array(6))) code += A[x % A.length];
        await db.prepare("INSERT INTO donations(code,name,msg,msg_ok,amount,created) VALUES(?,?,?,?,?,?)").bind(code, name, msg, msg && ok ? 1 : 0, amount, now).run();
        return J({ code, amount, content: cfg.template.replace("{ORDER CODE}", code), bank: cfg.bank, hidden: !!msg && !ok });
      }
      if (p === "/api/alerts") {
        if (u.searchParams.get("t") !== env.OVERLAY_TOKEN) return J({ error: "forbidden" }, 403);
        // con trỏ là thời gian trả tiền (ms), không phải id: donate tạo mã trước nhưng trả sau vẫn không bị bỏ sót
        const after = +u.searchParams.get("after"), now = Date.now();
        if (!after && after !== 0 || u.searchParams.get("after") === "latest") return J({ last: now, items: [] });
        const from = Math.max(after, now - 120000); // OBS ẩn/tạm dừng rồi hiện lại: chỉ phát alert trong 2 phút gần nhất, không phát lại đồ cũ
        const { results } = await db.prepare("SELECT id,name,amount,msg,msg_ok,audio,paid,status FROM donations WHERE status IN ('paid','test') AND paid>? ORDER BY paid,id LIMIT 10").bind(from).all();
        return J({ last: results.length ? results[results.length - 1].paid : after, items: results.map((r) => ({ id: r.id, name: r.name, amount: r.amount, msg: r.msg_ok ? r.msg : "", audio: r.audio, test: r.status === "test" })) });
      }
      if (p === "/api/stats") return cached(req, ctx, async () => {
        const d = new Date(); const ms = new Date(d.getFullYear(), d.getMonth(), 1).getTime();
        const t = await db.prepare("SELECT COALESCE(SUM(amount),0) s,COUNT(*) c,COALESCE(SUM(CASE WHEN paid>=? THEN amount END),0) m FROM donations WHERE status='paid'").bind(ms).first();
        const top = (await db.prepare("SELECT name,SUM(amount) s FROM donations WHERE status='paid' AND name!='Ẩn danh' GROUP BY name ORDER BY s DESC LIMIT 5").all()).results;
        const recent = (await db.prepare("SELECT name,amount,paid FROM donations WHERE status='paid' ORDER BY id DESC LIMIT 20").all()).results;
        return J({ total: t.s, count: t.c, month: t.m, top, recent });
      });
      if (p.startsWith("/admin/")) {
        if (req.headers.get("Authorization") !== "Bearer " + env.ADMIN_KEY) return J({ error: "Sai Admin key" }, 401);
        const b = await req.json();
        if (p === "/admin/secrets") { // chỉ còn SEPAY_KEY
          if (typeof b.set?.SEPAY_KEY === "string" && b.set.SEPAY_KEY.trim()) await env.KV.put("sec:SEPAY_KEY", b.set.SEPAY_KEY.trim());
          return J(b.get ? { SEPAY_KEY: await sec(env, "SEPAY_KEY") } : { ok: true });
        }
        // alert thử: audio = "mute" nghĩa là overlay không đọc giọng (alert thật luôn để trống = đọc theo cấu hình)
        if (p === "/admin/test") { const now = Date.now(), id = "T" + now + Math.floor(Math.random() * 1e4), msg = clean(b.msg, 200);
          await db.prepare("DELETE FROM donations WHERE status='test' AND created<?").bind(now - 3600000).run();
          await db.prepare("INSERT INTO donations(code,name,msg,msg_ok,amount,txn,status,audio,created,paid) VALUES(?,?,?,?,?,?,'test',?,?,?)").bind(id, clean(b.name, 24) || "Khách Test", msg, msg ? 1 : 0, Math.round(+b.amount || 0), id, b.audio === "mute" ? "mute" : "", now, now).run(); return J({ ok: true }); }
      }
      return J({ error: "not found" }, 404);
    }
  },
};
