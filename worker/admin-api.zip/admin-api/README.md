# Shinju Admin API (Cloudflare Worker)

Backend cho trang `/admin` của `shinjuvn.github.io`. Worker giữ `GITHUB_TOKEN` ở phía server, trang admin chỉ giữ phiên đăng nhập ngắn hạn.

Chức năng: đăng nhập admin · commit file lên GitHub · gợi ý SEO bằng Workers AI · báo Telegram (đăng nhập, mốc lượt xem/tải) · **tự cập nhật `sitemap.xml`**.

## Cấu trúc

```
admin-api/
├── src/index.js        # toàn bộ mã Worker
├── wrangler.toml       # cấu hình (biến, cron, AI)
├── package.json        # cài wrangler + các lệnh npm
├── .dev.vars.example   # mẫu biến để chạy thử trên máy
└── .gitignore
```

## Deploy

Cần Node.js 18+ và tài khoản Cloudflare.

```bash
cd admin-api
npm install
npx wrangler login

# 3 secret bắt buộc (mỗi lệnh sẽ hỏi giá trị, không hiện ra màn hình)
npx wrangler secret put ADMIN_PASSWORD     # mật khẩu đăng nhập /admin
npx wrangler secret put SESSION_SECRET     # chuỗi ngẫu nhiên dài >= 32 ký tự
npx wrangler secret put GITHUB_TOKEN       # xem mục "Tạo GITHUB_TOKEN"

# tùy chọn: báo Telegram
npx wrangler secret put TELEGRAM_BOT_TOKEN
npx wrangler secret put TELEGRAM_CHAT_ID

npm run deploy
```

Nếu Worker đã có secret từ trước thì **không cần đặt lại**, chỉ cần `npm run deploy`. Giữ nguyên `name = "shinju-admin-api"` để địa chỉ Worker không đổi (`admin/js/core.js` đang trỏ tới `https://shinju-admin-api.git-api.workers.dev`).

Kiểm tra trước khi deploy: `npm run check` (đóng gói thử, không đăng lên). Xem log khi đang chạy: `npm run tail`.

### Tạo GITHUB_TOKEN

GitHub → Settings → Developer settings → Fine-grained tokens → Generate new token:
- Repository access: **Only select repositories** → chọn repo web `shinjuvn.github.io`
- Permissions → **Contents: Read and write**
- Dán token vào lệnh `wrangler secret put GITHUB_TOKEN`

### Telegram (tùy chọn)

1. Chat với `@BotFather` → `/newbot` → lấy token → `TELEGRAM_BOT_TOKEN`.
2. Nhắn bot một tin bất kỳ, lấy chat id của bạn → `TELEGRAM_CHAT_ID`.
3. Vào `/admin` → Cài đặt → Telegram → bấm **Gửi tin thử**.

## Cron (đã khai báo trong `wrangler.toml`)

| Cron (UTC) | Giờ VN | Việc làm |
|---|---|---|
| `0 * * * *` | mỗi giờ | So lượt xem/tải với các mốc đã đặt, báo Telegram (chỉ chạy khi bạn bật trong Cài đặt) |

## Sitemap tự động

Worker giữ `sitemap.xml`; mọi commit từ trang admin đều được cập nhật sitemap trong **cùng commit**:

- Đăng/sửa bài, sửa `/channel`, `/donate`, lưu Cài đặt → `lastmod` của trang đó = hôm nay (giờ VN).
- Xóa bài/ảnh hoặc chuyển bài sang riêng tư → URL bị gỡ khỏi sitemap.
- Ảnh/PDF mới → thêm vào sitemap; ảnh đã có rồi thì giữ nguyên, **không đổi `lastmod`**.
- "Làm mới hàng loạt" chỉ thêm mục còn thiếu, không đổi `lastmod` mục đã có.

**Không còn quét toàn bộ repo**: đã bỏ nút *Quét và cập nhật sitemap*, endpoint `/sitemap/scan` và cron quét mỗi ngày. Sitemap chỉ đổi theo từng commit từ trang admin; muốn thêm URL khác thì sửa `sitemap.xml` trực tiếp.

Tùy chỉnh trong `site-settings.json` (sửa bằng nút *Sửa file site-settings.json*):

```json
"sitemap": { "exclude": ["post/photo/", "assets/anh-rieng.png"] }
```

- `exclude`: thêm đường dẫn muốn loại (thư mục kết thúc bằng `/`).
- Tên miền khác mặc định: đặt `seo.siteUrl` trong `site-settings.json` hoặc biến `SITE_URL` trong `wrangler.toml`.

## Giới hạn của Worker (gói Free) và cách code tránh

- **50 lệnh gọi ra ngoài / lần chạy:** commit 40 file ≈ 48 lệnh. Không tải từng file, không kiểm tra từng URL. Gói trả phí có thể nâng `MAX_FILES_PER_COMMIT` và đặt `SUBREQUEST_LIMIT`.
- **CPU ~10 ms / lần chạy:** chỉ xử lý chuỗi/regex trên dữ liệu đã tải, không dùng bộ đọc XML nặng.
- **Sitemap tối đa 50.000 URL** (giới hạn của giao thức).
- **Không ghi đè mất thay đổi của người khác:** commit không dùng force; có ai commit chen vào giữa thì báo lỗi, thử lại là được.
- **Lỗi sitemap không chặn việc đăng bài:** commit vẫn thành công, kết quả có trường `sitemap`.

## Các đường dẫn API

| Đường dẫn | Mô tả |
|---|---|
| `POST /login` | Đăng nhập, trả phiên ngắn hạn (sai 5 lần khóa 10 phút) |
| `GET /ping?deep=1` | Kiểm tra token GitHub và quyền ghi repo |
| `GET /tree`, `GET /file?path=` | Đọc cây thư mục và file văn bản của repo |
| `POST /commit` | Ghi/xóa nhiều file trong một commit (kèm cập nhật sitemap) |
| `POST /notify/test` | Gửi tin Telegram thử |
| `POST /ai/seo` | Gợi ý tiêu đề/mô tả/từ khóa SEO bằng Workers AI |

## Khắc phục sự cố

- **Đăng nhập báo "origin"**: `ALLOWED_ORIGIN` trong `wrangler.toml` phải đúng `https://shinjuvn.github.io` (không có dấu `/` cuối).
- **GitHub 401/403**: token sai, hết hạn hoặc thiếu quyền *Contents: Read and write* cho repo web → tạo token mới, chạy lại `wrangler secret put GITHUB_TOKEN`.
- **Sitemap không đổi sau khi đăng bài**: xem `npm run tail`, và kiểm tra kết quả `/commit` có trường `sitemap: "error: …"` không.
- **Cron không thấy chạy**: Cloudflare Dashboard → Workers → `shinju-admin-api` → Settings → Triggers, phải thấy 1 cron ở trên (mỗi giờ).
