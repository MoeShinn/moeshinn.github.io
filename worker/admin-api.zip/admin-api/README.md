# Shinju Admin API (Cloudflare Worker)

Backend cho trang `/admin` của `shinjuvn.github.io`. Worker giữ `GITHUB_TOKEN` ở phía server, trang admin chỉ giữ phiên đăng nhập ngắn hạn.

Chức năng: đăng nhập admin · commit file lên GitHub · gợi ý SEO bằng Workers AI · báo Telegram (đăng nhập, mốc lượt xem/tải) · **tự cập nhật `sitemap.xml`** · **bán model bằng mã tải** (xem mục “Bán model bằng mã”).

## Cấu trúc

```
admin-api/
├── src/index.js        # toàn bộ mã Worker
├── wrangler.toml       # cấu hình (biến, cron, AI)
├── package.json        # cài wrangler + các lệnh npm
├── .dev.vars.example   # mẫu biến để chạy thử trên máy
└── .gitignore
```

## Deploy

Cần Node.js 18+ và tài khoản Cloudflare.

```bash
cd admin-api
npm install
npx wrangler login

# 3 secret bắt buộc (mỗi lệnh sẽ hỏi giá trị, không hiện ra màn hình)
npx wrangler secret put ADMIN_PASSWORD     # mật khẩu đăng nhập /admin
npx wrangler secret put SESSION_SECRET     # chuỗi ngẫu nhiên dài >= 32 ký tự
npx wrangler secret put GITHUB_TOKEN       # xem mục "Tạo GITHUB_TOKEN"

# tùy chọn: báo Telegram
npx wrangler secret put TELEGRAM_BOT_TOKEN
npx wrangler secret put TELEGRAM_CHAT_ID

npm run deploy
```

Nếu Worker đã có secret từ trước thì **không cần đặt lại**, chỉ cần `npm run deploy`. Giữ nguyên `name = "shinju-admin-api"` để địa chỉ Worker không đổi (`admin/js/core.js` đang trỏ tới `https://shinju-admin-api.git-api.workers.dev`).

Kiểm tra trước khi deploy: `npm run check` (đóng gói thử, không đăng lên). Xem log khi đang chạy: `npm run tail`.

### Tạo GITHUB_TOKEN

GitHub → Settings → Developer settings → Fine-grained tokens → Generate new token:
- Repository access: **Only select repositories** → chọn repo web `shinjuvn.github.io`
- Permissions → **Contents: Read and write**
- Dán token vào lệnh `wrangler secret put GITHUB_TOKEN`

### Telegram (tùy chọn)

1. Chat với `@BotFather` → `/newbot` → lấy token → `TELEGRAM_BOT_TOKEN`.
2. Nhắn bot một tin bất kỳ, lấy chat id của bạn → `TELEGRAM_CHAT_ID`.
3. Vào `/admin` → Cài đặt → Telegram → bấm **Gửi tin thử**.

## Cron (đã khai báo trong `wrangler.toml`)

| Cron (UTC) | Giờ VN | Việc làm |
|---|---|---|
| `0 * * * *` | mỗi giờ | So lượt xem/tải với các mốc đã đặt, báo Telegram (chỉ chạy khi bạn bật trong Cài đặt) |

## Sitemap tự động

Worker giữ `sitemap.xml`; mọi commit từ trang admin đều được cập nhật sitemap trong **cùng commit**:

- Đăng/sửa bài, sửa `/channel`, `/donate`, lưu Cài đặt → `lastmod` của trang đó = hôm nay (giờ VN).
- Xóa bài/ảnh hoặc chuyển bài sang riêng tư → URL bị gỡ khỏi sitemap.
- Ảnh/PDF mới → thêm vào sitemap; ảnh đã có rồi thì giữ nguyên, **không đổi `lastmod`**.
- "Làm mới hàng loạt" chỉ thêm mục còn thiếu, không đổi `lastmod` mục đã có.

**Không còn quét toàn bộ repo**: đã bỏ nút *Quét và cập nhật sitemap*, endpoint `/sitemap/scan` và cron quét mỗi ngày. Sitemap chỉ đổi theo từng commit từ trang admin; muốn thêm URL khác thì sửa `sitemap.xml` trực tiếp.

Tùy chỉnh trong `site-settings.json` (sửa bằng nút *Sửa file site-settings.json*):

```json
"sitemap": { "exclude": ["post/photo/", "assets/anh-rieng.png"] }
```

- `exclude`: thêm đường dẫn muốn loại (thư mục kết thúc bằng `/`).
- Tên miền khác mặc định: đặt `seo.siteUrl` trong `site-settings.json` hoặc biến `SITE_URL` trong `wrangler.toml`.

## Giới hạn của Worker (gói Free) và cách code tránh

- **50 lệnh gọi ra ngoài / lần chạy:** commit 40 file ≈ 48 lệnh. Không tải từng file, không kiểm tra từng URL. Gói trả phí có thể nâng `MAX_FILES_PER_COMMIT` và đặt `SUBREQUEST_LIMIT`.
- **CPU ~10 ms / lần chạy:** chỉ xử lý chuỗi/regex trên dữ liệu đã tải, không dùng bộ đọc XML nặng.
- **Sitemap tối đa 50.000 URL** (giới hạn của giao thức).
- **Không ghi đè mất thay đổi của người khác:** commit không dùng force; có ai commit chen vào giữa thì báo lỗi, thử lại là được.
- **Lỗi sitemap không chặn việc đăng bài:** commit vẫn thành công, kết quả có trường `sitemap`.

## Các đường dẫn API

| Đường dẫn | Mô tả |
|---|---|
| `POST /login` | Đăng nhập, trả phiên ngắn hạn (sai 5 lần khóa 10 phút) |
| `GET /ping?deep=1` | Kiểm tra token GitHub và quyền ghi repo |
| `GET /tree`, `GET /file?path=` | Đọc cây thư mục và file văn bản của repo |
| `POST /commit` | Ghi/xóa nhiều file trong một commit (kèm cập nhật sitemap) |
| `POST /notify/test` | Gửi tin Telegram thử |
| `POST /ai/seo` | Gợi ý tiêu đề/mô tả/từ khóa SEO bằng Workers AI |
| `POST /buy/redeem` | **Công khai** (chỉ từ origin của bạn): khách gửi mã, nhận vé tải 5 phút |
| `GET /buy/status?t=` | **Công khai**: trạng thái lượt tải của vé (trang /buy dùng để báo “đã tải xong”) |
| `GET /buy/dl?t=` | **Công khai** (cần vé ký): truyền file từ repo private về máy khách |
| `/buy-admin/*` | Cần đăng nhập admin: kiểm tra kết nối, sản phẩm, tạo/thu hồi mã |

## Khắc phục sự cố

- **Đăng nhập báo "origin"**: `ALLOWED_ORIGIN` trong `wrangler.toml` phải đúng `https://shinjuvn.github.io` (không có dấu `/` cuối).
- **GitHub 401/403**: token sai, hết hạn hoặc thiếu quyền *Contents: Read and write* cho repo web → tạo token mới, chạy lại `wrangler secret put GITHUB_TOKEN`.
- **Sitemap không đổi sau khi đăng bài**: xem `npm run tail`, và kiểm tra kết quả `/commit` có trường `sitemap: "error: …"` không.
- **Cron không thấy chạy**: Cloudflare Dashboard → Workers → `shinju-admin-api` → Settings → Triggers, phải thấy 1 cron ở trên (mỗi giờ).

## Bán model bằng mã

Khách trả tiền → bạn tạo mã ở `/admin/buy/` → gửi mã → khách vào `/buy/`, dán mã và tải. File nằm trong **release của repo private**; không có link công khai nào, và khách không bao giờ thấy link GitHub.

```
/admin/buy/ ──tạo mã──▶ KV "BUY" (mã, lượt, hạn)          GitHub repo PRIVATE (release "models")
/buy/  ──dán mã──▶ Worker ──kiểm tra──▶ vé HMAC 5 phút        ▲
/buy/dl?t=vé ──▶ Worker ──────lấy file bằng token────────────┘ rồi truyền thẳng về máy khách
```

Điểm chính:

- **Mã** `XXXXX-XXXXX-XXXXX`: 15 ký tự từ bảng 31 ký tự (bỏ `0 O 1 I L`), ~74 bit, không đoán được. Dán mã kèm dấu cách, xuống dòng, chữ thường, hay cả câu “mã của bạn là …” đều được lọc ra đúng mã.
- **Tên file khi tải**: `<tên gốc>-<6 ký tự ngẫu nhiên>.<đuôi>`, mỗi lần tải một tên khác. Tên thật trong release không lộ.
- **Lượt tải chỉ bị trừ khi file đã truyền hết** cho trình duyệt. Khách ngắt giữa chừng thì không mất lượt; trang `/buy/` hỏi Worker và hiện “✅ Tải xong” hoặc “bị gián đoạn”.
- Mỗi mã chỉ chạy **1 luồng tải một lúc** (khoá tự nhả khi xong/lỗi, tối đa 20 phút; admin có nút **Mở khoá**).
- **Chặn dò mã**: sai 10 lần liên tiếp từ một IP → khoá 15 phút. Nhập sai **không ghi KV**.
- **Chỉ gọi từ trang của bạn**: `/buy/redeem` và `/buy/status` từ chối mọi request không có `Origin` nằm trong `ALLOWED_ORIGIN`. Đây là lớp chặn script “lười” và trang web lạ, **không phải** bảo mật tuyệt đối (công cụ như curl vẫn giả được header). Bảo vệ thật là: mã không đoán được + khoá thử sai + vé ký ngắn hạn.
- Có cấu hình Telegram thì mỗi lượt tải xong báo về điện thoại (tên sản phẩm, mã, ghi chú khách, IP).

### Cài đặt (làm một lần)

1. **Repo private chứa file bán.** GitHub → New repository → Private (vd `shinju-models`), tick “Add a README” (release cần repo có ít nhất 1 commit). Đặt tên đó vào `RELEASE_REPO` trong `wrangler.toml`.
2. **Token GitHub**: Settings → Developer settings → Fine-grained tokens → mở token đang dùng → *Repository access: Only select repositories* → chọn đúng **2 repo**: repo web và repo private ở bước 1. Permissions giữ **Contents: Read and write** (đủ để tạo release, tải tệp lên, xoá tệp). Nếu GitHub không cho sửa, tạo token mới rồi `npx wrangler secret put GITHUB_TOKEN`.
3. **KV lưu mã**: `npx wrangler kv namespace create BUY` → dán `id` vào `[[kv_namespaces]]` trong `wrangler.toml`.
4. `npm run deploy` (secret cũ giữ nguyên, không đặt lại).
5. **Chép các file web** (thư mục `shinjuvn.github.io/` trong gói) đè vào repo web rồi commit:
   - `buy/index.html`, `buy/css/style.css`, `buy/js/main.js` (trang khách)
   - `admin/buy/index.html` (trang quản trị)
   - `admin/js/core.js` (thêm mục menu “Bán hàng” và hàm tải file lên có thanh tiến trình)
   - `robots.txt`, `tools/prerender.js` (chỉ thêm `/buy/` vào danh sách loại khỏi sitemap)
6. Mở `/admin/buy/` → thẻ **Kết nối** phải toàn dấu xanh. Nếu báo repo “PUBLIC” thì chuyển sang Private ngay (repo public thì ai cũng tải thẳng được).

Trang `/buy/` không được đưa vào menu, không vào sitemap, `noindex` và `Disallow` trong `robots.txt`. Bạn gửi link `https://<tên-miền>/buy/` cùng mã cho khách.

### Dùng hằng ngày

1. `/admin/buy/` → **Thêm sản phẩm mới**: chọn tệp (mọi định dạng), đặt tên hiển thị, bấm *Tải lên*. File ≥ ~95 MB: vào GitHub → repo private → Releases → release `models` → thêm tệp bằng giao diện web, rồi ở admin mở mục *Dùng tệp đã có trong release*.
2. **Tạo mã**: chọn sản phẩm, số mã, số lượt tải mỗi mã (mặc định 2), hạn dùng, ghi chú người mua → *Sao chép tin nhắn gửi khách* → dán vào Zalo/Messenger.
3. Theo dõi ở bảng **Danh sách mã**: trạng thái (chưa dùng hết / đang tải / hết lượt / hết hạn / thu hồi), thu hồi, cộng lượt, đổi hạn, mở khoá, xoá.

### Đổi username GitHub

Khách vẫn dùng được trong lúc chuyển: thêm địa chỉ mới vào `ALLOWED_ORIGIN` (cách nhau dấu phẩy, giữ địa chỉ cũ một thời gian), đổi `GITHUB_OWNER` / `GITHUB_REPO` / `COUNTERS_REPO` / `RELEASE_REPO` cho khớp, rồi `npm run deploy`. Các file web mới viết toàn đường dẫn tương đối nên không phải sửa. Địa chỉ Worker (`shinju-admin-api.git-api.workers.dev`) không đổi theo username; nếu bạn đổi Worker, sửa hằng `API` ở `admin/js/core.js` và `buy/js/main.js`.

### Giới hạn cần biết

- **KV gói Free: 1.000 lượt ghi/ngày**. Mỗi đơn tốn khoảng 3 lượt ghi (tạo mã, bắt đầu tải, tải xong) nên dư sức cho hàng trăm đơn mỗi ngày. KV đọc chéo vùng có thể trễ tới ~60 giây, nên hiếm khi hai thiết bị bấm cùng lúc có thể cùng qua được cổng “1 luồng một lúc”; hậu quả chỉ là tải thêm một lượt, không lộ file.
- **Tải lên qua trang admin tối đa ~95 MB** (Cloudflare giới hạn thân yêu cầu ~100 MB ở gói Free/Pro). Lớn hơn: thêm tệp vào release bằng giao diện GitHub (tối đa 2 GB/tệp).
- Dữ liệu tải về đi qua Worker nhưng chỉ là truyền luồng, gần như không tốn CPU nên vẫn nằm trong hạn mức Free.
- Mỗi lần tải: 2 lệnh gọi GitHub (lấy link ký, tải file). Lượt gọi API của token là 5.000/giờ, dư rất nhiều.
- Nên thêm một **Rate Limiting Rule** của Cloudflare cho đường dẫn `/buy/redeem` (gói Free có 1 rule) để chắc hơn việc khoá theo IP trong bộ nhớ Worker (mỗi isolate giữ riêng).
- Không có cách kỹ thuật nào ngăn khách đã tải xong gửi file cho người khác. Mã nào, ghi chú nào, tải lúc nào, từ IP nào đều lưu/báo Telegram để bạn truy ra nguồn.
