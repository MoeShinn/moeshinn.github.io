// Shinju Admin API — Cloudflare Worker.
// Giữ GITHUB_TOKEN (quyền ghi repo web) ở phía server; trang /admin chỉ giữ phiên ngắn hạn.
const enc = new TextEncoder();
// Dán secret vào cmd đôi khi kèm ký tự điều khiển/khoảng trắng ẩn → lọc bỏ trước khi dùng.
const cleanSecret = (v) => String(v ?? "").replace(/\x1b\[[0-9;?]*[ -\/]*[@-~]/g, "").trim();
const cleanToken = (v) => cleanSecret(v).replace(/[^\x21-\x7e]/g, ""); // token GitHub/Telegram chỉ gồm ký tự ASCII in được
const TOKEN_KEYS = new Set(["GITHUB_TOKEN", "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID"]);
// Làm sạch TẤT CẢ biến/secret dạng chuỗi ngay khi nhận (dấu cách, xuống dòng, mã dán ẩn); binding như env.AI giữ nguyên.
function cleanEnv(env) {
  const o = { ...env };
  for (const [k, v] of Object.entries(env)) if (typeof v === "string") o[k] = TOKEN_KEYS.has(k) ? cleanToken(v) : cleanSecret(v);
  if (o.ALLOWED_ORIGIN) o.ALLOWED_ORIGIN = o.ALLOWED_ORIGIN.replace(/\/+$/, ""); // origin không có dấu / ở cuối
  return o;
}
const b64u = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const unb64u = (s) => Uint8Array.from(atob(s.replace(/-/g, "+").replace(/_/g, "/")), (c) => c.charCodeAt(0));

let lastCommit = 0; // chống bấm dồn dập (theo từng isolate)
const failedLogins = new Map(); // ip -> {n, until}  (theo từng isolate; bổ sung Rate Limiting Rule của Cloudflare để chắc hơn)

const cors = (env) => ({
  "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN,
  "Access-Control-Allow-Headers": "Authorization, Content-Type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Vary": "Origin",
});
const json = (env, data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store", ...cors(env) } });

async function hmacKey(env, usage) {
  return crypto.subtle.importKey("raw", enc.encode(env.SESSION_SECRET), { name: "HMAC", hash: "SHA-256" }, false, usage);
}
async function makeToken(env) {
  const exp = Math.floor(Date.now() / 1000) + (Number(env.SESSION_TTL_SECONDS) || 3600);
  const payload = b64u(enc.encode(JSON.stringify({ exp })));
  const sig = await crypto.subtle.sign("HMAC", await hmacKey(env, ["sign"]), enc.encode(payload));
  return { token: `${payload}.${b64u(sig)}`, exp };
}
async function tokenOk(env, req) {
  const m = (req.headers.get("Authorization") || "").match(/^Bearer (.+)\.(.+)$/);
  if (!m) return false;
  try {
    const good = await crypto.subtle.verify("HMAC", await hmacKey(env, ["verify"]), unb64u(m[2]), enc.encode(m[1]));
    return good && JSON.parse(new TextDecoder().decode(unb64u(m[1]))).exp > Date.now() / 1000;
  } catch { return false; }
}
async function passwordOk(env, given) {
  const [a, b] = await Promise.all([String(given).trim(), env.ADMIN_PASSWORD].map((v) => crypto.subtle.digest("SHA-256", enc.encode(v))));
  return crypto.subtle.timingSafeEqual(a, b);
}

// ---- GitHub ----
async function gh(env, path, { method = "GET", body, accept = "application/vnd.github+json" } = {}) {
  const res = await fetch(`https://api.github.com${path}`, {
    method,
    headers: { Authorization: `Bearer ${env.GITHUB_TOKEN}`, Accept: accept, "User-Agent": "shinju-admin-api", "X-GitHub-Api-Version": "2022-11-28", ...(body ? { "Content-Type": "application/json" } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) throw Object.assign(new Error(`GitHub ${res.status} (${method} ${path.replace(/\?.*$/, "")}): ${(await res.text()).slice(0, 300)}`), { status: res.status, github: true }); // ghi rõ yêu cầu nào bị từ chối để dễ tìm lỗi
  return res;
}
const repoBase = (env) => `/repos/${env.GITHUB_OWNER}/${env.GITHUB_REPO}`;
// Chặn đường dẫn nguy hiểm: thoát thư mục, .git, và workflow (tránh cài Actions lạ nếu lộ phiên).
const safePath = (p) => typeof p === "string" && p && !p.startsWith("/") && !p.split("/").some((s) => s === ".." || s === ".git") && !p.startsWith(".github/");

async function commitFiles(env, { message, files = [], deletes = [], edit }) {
  const base = repoBase(env), br = env.GITHUB_BRANCH || "main";
  const head = (await (await gh(env, `${base}/git/ref/heads/${br}`)).json()).object.sha;
  const parent = await (await gh(env, `${base}/git/commits/${head}`)).json();
  // edit({head, tree}) có thể trả thêm file (vd sitemap.xml). Nó đọc dữ liệu đúng tại commit cha `head`, còn bước PATCH ref bên dưới
  // không-force nên nếu có ai commit chen vào giữa thì báo lỗi, không bao giờ ghi đè mất thay đổi của người khác.
  if (edit) { const extra = await edit({ head, tree: parent.tree.sha }); if (extra?.length) files = files.concat(extra); }
  if (!files.length && !deletes.length) return null; // không có gì để ghi → không tạo commit rỗng (đỡ build lại GitHub Pages)
  const tree = [];
  for (const f of files) {
    const blob = await (await gh(env, `${base}/git/blobs`, { method: "POST", body: { content: f.content, encoding: f.encoding === "base64" ? "base64" : "utf-8" } })).json();
    tree.push({ path: f.path, mode: "100644", type: "blob", sha: blob.sha });
  }
  for (const p of deletes) tree.push({ path: p, mode: "100644", type: "blob", sha: null });
  const newTree = await (await gh(env, `${base}/git/trees`, { method: "POST", body: { base_tree: parent.tree.sha, tree } })).json();
  const c = await (await gh(env, `${base}/git/commits`, { method: "POST", body: { message, tree: newTree.sha, parents: [head] } })).json();
  await gh(env, `${base}/git/refs/heads/${br}`, { method: "PATCH", body: { sha: c.sha } }); // không force: có xung đột thì báo lỗi
  return c.sha;
}

// ---- Telegram: cảnh báo đăng nhập + mốc lượt xem/tải ----
const h = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
async function tg(env, text) {
  if (!env.TELEGRAM_BOT_TOKEN || !env.TELEGRAM_CHAT_ID) return false;
  const r = await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`, { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: env.TELEGRAM_CHAT_ID, text, parse_mode: "HTML", disable_web_page_preview: true }) });
  return r.ok;
}
async function readRepoJson(env, path, fallback) {
  try { return JSON.parse(await (await gh(env, `${repoBase(env)}/contents/${path}?ref=${env.GITHUB_BRANCH || "main"}`, { accept: "application/vnd.github.raw+json" })).text()); }
  catch (e) { if (e.status === 404 || e instanceof SyntaxError) return fallback; throw e; }
}
const readSettings = (env) => readRepoJson(env, "site-settings.json", {}).catch(() => ({}));
async function alertAdmin(env, req, kind) { // kind: "login" | "lock"
  try {
    const T = (await readSettings(env)).telegram || {};
    if (kind === "login" ? T.login === false : T.loginFail === false) return;
    const when = new Date().toLocaleString("vi-VN", { timeZone: "Asia/Ho_Chi_Minh" });
    const who = `🌐 IP: <code>${h(req.headers.get("CF-Connecting-IP") || "?")}</code> (${h(req.cf?.country || "?")})\n📱 ${h((req.headers.get("User-Agent") || "?").slice(0, 120))}`;
    await tg(env, kind === "login" ? `🔐 <b>Đăng nhập trang admin</b>\n🕒 ${when}\n${who}` : `⚠️ <b>Nhập sai mật khẩu admin 5 lần</b> — đã khóa 10 phút\n🕒 ${when}\n${who}`);
  } catch (e) { /* cảnh báo hỏng không được làm hỏng đăng nhập */ }
}
const parseTh = (v) => [...new Set((Array.isArray(v) ? v : String(v || "").split(/[,\s]+/)).map(Number).filter((n) => n > 0))].sort((a, b) => a - b);
const AI_FALLBACKS = ["@cf/meta/llama-3.3-70b-instruct-fp8-fast", "@cf/meta/llama-3.1-8b-instruct-fp8", "@cf/google/gemma-4-26b-a4b-it"]; // theo danh mục Workers AI (08/2026)
// Mỗi model trả về một kiểu: {response}, {choices:[{message}]}, ... → gom về chuỗi
const aiText = (o) => (typeof o === "string" ? o : o ? String(o.response ?? o.result?.response ?? o.choices?.[0]?.message?.content ?? o.output_text ?? "") : "");
const MAX_ITEMS = 35; // gói Free: tối đa 50 lệnh gọi ra ngoài mỗi lần chạy → giữ chỗ cho các lệnh khác
// Chạy theo giờ (Cron): so lượt xem/tải với các mốc đã đặt; mốc đã báo được lưu trong site-notify-state.json
async function checkMilestones(env) {
  const T = (await readSettings(env)).telegram || {};
  const vTh = T.views?.enabled ? parseTh(T.views.thresholds) : [], dTh = T.downloads?.enabled ? parseTh(T.downloads.thresholds) : [];
  if (!vTh.length && !dTh.length) return { skipped: true };
  const [posts, tree, state] = await Promise.all([readRepoJson(env, "post/data/posts.json", []), gh(env, `${repoBase(env)}/git/trees/${env.GITHUB_BRANCH || "main"}?recursive=1`).then((r) => r.json()), readRepoJson(env, "site-notify-state.json", {})]);
  const items = [];
  if (vTh.length) posts.filter((p) => p.visibility !== "private").forEach((p) => items.push({ key: "v:" + p.id, id: p.id, type: "view", field: "views", th: vTh, title: p.title }));
  if (dTh.length) tree.tree.map((x) => (x.path.match(/^download\/data\/([^/]+)\.json$/) || [])[1]).filter(Boolean).forEach((id) => items.push({ key: "d:" + id, id, type: "download", field: "downloads", th: dTh }));
  const repo = env.COUNTERS_REPO || `${env.GITHUB_OWNER}/api-counters`;
  const counts = await Promise.all(items.slice(0, MAX_ITEMS).map(async (it) => { try { const r = await fetch(`https://raw.githubusercontent.com/${repo}/main/${it.type}-${encodeURIComponent(it.id)}.json?t=${Date.now()}`); return r.ok ? (await r.json())[it.field] || 0 : 0; } catch (e) { return null; } }));
  const site = `https://${env.GITHUB_REPO}`; let changed = false, sent = 0;
  for (const [i, it] of items.slice(0, MAX_ITEMS).entries()) {
    const n = counts[i]; if (n == null) continue;
    const top = Math.max(0, ...it.th.filter((t) => n >= t));
    if (state[it.key] === undefined) { state[it.key] = top; changed = true; continue; } // lần đầu thấy mục này: chỉ ghi mốc, không báo mốc cũ
    if (top > state[it.key]) {
      let title = it.title;
      if (it.type === "download") title = (await readRepoJson(env, `download/data/${it.id}.json`, {}).catch(() => ({}))).title || it.id;
      const url = `${site}/${it.type === "view" ? "post" : "download"}/${encodeURIComponent(it.id)}/`;
      await tg(env, it.type === "view" ? `📈 Bài <b>${h(title)}</b> đã đạt <b>${top.toLocaleString("vi-VN")}</b> lượt xem\n${url}` : `⬇️ Mục tải <b>${h(title)}</b> đã đạt <b>${top.toLocaleString("vi-VN")}</b> lượt tải\n${url}`);
      state[it.key] = top; changed = true; sent++;
    }
  }
  if (changed) await commitFiles(env, { message: "Bot: cập nhật mốc thông báo Telegram", files: [{ path: "site-notify-state.json", content: JSON.stringify(state, null, 2) + "\n" }] });
  return { checked: Math.min(items.length, MAX_ITEMS), sent };
}

// ---- Sitemap: Worker giữ sitemap.xml ----
// Giới hạn Worker (gói Free) đã tính sẵn: tối đa 50 lệnh gọi ra ngoài + ~10 ms CPU mỗi lần chạy.
//  • Không còn chức năng quét toàn repo / cron quét sitemap: sitemap chỉ được cập nhật theo từng commit từ trang admin.
//  • Chỉ dùng chuỗi/regex trên dữ liệu đã tải (không có bộ đọc XML nặng); không có URL mới thì không commit.
//  • Mỗi lần /commit của trang admin tốn thêm 2 lệnh đọc (sitemap + cài đặt); tự bỏ qua nếu sẽ vượt giới hạn lệnh gọi.
const SM_HEAD = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
const SM_MAX = 50000; // giới hạn của giao thức sitemap: 50.000 URL mỗi file
const SM_IMG = /\.(png|jpe?g|webp|gif|avif|svg|bmp)$/i, SM_DOC = /\.pdf$/i; // chỉ file xem được công khai; .js/.css/.json/.md/... không bao giờ vào sitemap
const SM_SKIP = ["admin/", "s/", "assets/favicon/", "assets/donate/", "node_modules/"]; // s/ = trang chuyển hướng (noindex); favicon/QR không cần Google Images. Thêm bớt qua site-settings.json → sitemap.exclude
// Trang không có file index.html riêng nhưng đổi dữ liệu thì đổi nội dung trang → đặt lastmod hôm nay
const SM_DATA = { "channel/data.json": ["/channel/"], "donate/data.json": ["/donate/"], "data.json": ["/"], "post/data/posts.json": ["/post/", "/"] };
const smToday = () => new Date(Date.now() + 7 * 3600 * 1000).toISOString().slice(0, 10); // ngày theo giờ Việt Nam
const xmlEsc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const xmlUnesc = (s) => String(s).replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&");
const canon = (u) => { try { return decodeURI(u); } catch (e) { return u; } }; // so khớp URL không phân biệt %-mã hóa
const smKind = (p) => (/(^|\/)index\.html$/.test(p) ? "page" : SM_IMG.test(p) ? "image" : SM_DOC.test(p) ? "doc" : null);
const smExcluded = (p, extra = []) => p.split("/").some((s) => s.startsWith(".") || s === "node_modules") || [...SM_SKIP, ...extra].some((x) => p.startsWith(x));
const smExtra = (s) => (Array.isArray(s?.sitemap?.exclude) ? s.sitemap.exclude : []).map((x) => String(x).replace(/^\/+/, "")).filter(Boolean);
// dir/index.html → /dir/ (không kèm index.html) ; ảnh → /đường/dẫn.webp
const smUrl = (base, p) => { const m = p.match(/^(?:(.*)\/)?index\.html$/); return base + (m ? (m[1] ? "/" + m[1].split("/").map(encodeURIComponent).join("/") + "/" : "/") : "/" + p.split("/").map(encodeURIComponent).join("/")); };
const siteBase = (env, xml, S) => String(env.SITE_URL || S?.seo?.siteUrl || (String(xml).match(/<loc>\s*(https?:\/\/[^/<\s]+)/) || [])[1] || `https://${env.GITHUB_REPO}`).replace(/\/+$/, "");

// Đọc file văn bản tại một commit cụ thể; không có file → ""
async function readAt(env, path, ref) {
  try { return await (await gh(env, `${repoBase(env)}/contents/${path.split("/").map(encodeURIComponent).join("/")}?ref=${ref}`, { accept: "application/vnd.github.raw+json" })).text(); }
  catch (e) { if (e.status === 404) return ""; throw e; }
}
const readSettingsAt = async (env, ref) => { try { return JSON.parse((await readAt(env, "site-settings.json", ref)) || "{}"); } catch (e) { return {}; } };

function smParse(xml) {
  xml = String(xml || ""); const re = /<url>[\s\S]*?<\/url>/g, entries = []; let first = -1, m;
  while ((m = re.exec(xml))) { if (first < 0) first = m.index; const loc = (m[0].match(/<loc>\s*([^<]*?)\s*<\/loc>/) || [])[1]; entries.push({ key: loc == null ? null : canon(xmlUnesc(loc)), raw: m[0] }); }
  return { head: first < 0 ? SM_HEAD : xml.slice(0, first).replace(/\s+$/, ""), eol: xml.includes("\r\n") ? "\r\n" : "\n", entries, map: new Map(entries.filter((e) => e.key).map((e) => [e.key, e])) };
}
// Mục chưa đổi giữ nguyên từng byte; mục khác (kể cả thẻ lạ như <image:image>) không bị đụng tới
const smBuild = (sm) => sm.head + sm.eol + sm.entries.map((e) => "  " + e.raw + sm.eol).join("") + "</urlset>" + sm.eol;
function smAdd(sm, loc, d) { // chỉ thêm khi CHƯA có; mục đã có giữ nguyên, kể cả lastmod
  const key = canon(loc); if (sm.map.has(key) || sm.entries.length >= SM_MAX) return false;
  const e = { key, raw: `<url><loc>${xmlEsc(loc)}</loc>${d ? `<lastmod>${d}</lastmod>` : ""}</url>` };
  sm.entries.push(e); sm.map.set(key, e); return true;
}
function smTouch(sm, loc, d) { // đặt lastmod = d (thêm mới nếu chưa có)
  const e = sm.map.get(canon(loc)); if (!e) return smAdd(sm, loc, d);
  const next = /<lastmod>/.test(e.raw) ? e.raw.replace(/<lastmod>[^<]*<\/lastmod>/, `<lastmod>${d}</lastmod>`) : e.raw.replace("</loc>", `</loc><lastmod>${d}</lastmod>`);
  if (next === e.raw) return false; e.raw = next; return true;
}
function smRemove(sm, loc) {
  const key = canon(loc), e = sm.map.get(key); if (!e) return false;
  sm.map.delete(key); sm.entries.splice(sm.entries.indexOf(e), 1); return true;
}
const smRelevant = (files, deletes) => [...files.map((f) => f.path), ...deletes].some((p) => smKind(p) || SM_DATA[p]);

// Áp thay đổi của MỘT commit lên sitemap. Trả về nội dung mới, hoặc null nếu không có gì đổi.
function smApplyCommit(xml, { files, deletes, base, extra }) {
  const sm = smParse(xml), d = smToday(); let changed = false;
  const paths = files.map((f) => f.path).filter((p) => !smExcluded(p, extra));
  // Một lần đăng/sửa chỉ ghi 1 trang bài/mục tải. Nhiều hơn = tạo lại hàng loạt → chỉ thêm mục còn thiếu, không đổi lastmod mục đã có
  const bulk = paths.filter((p) => /^(post|download)\/[^/]+\/index\.html$/.test(p)).length > 1;
  for (const p of paths) {
    const k = smKind(p);
    if (k === "page") changed = (bulk ? smAdd(sm, smUrl(base, p), d) : smTouch(sm, smUrl(base, p), d)) || changed; // trang đổi → lastmod hôm nay
    else if (k) changed = smAdd(sm, smUrl(base, p), d) || changed; // ảnh/pdf: có rồi thì không thêm, không đổi lastmod
    else if (SM_DATA[p] && !bulk) for (const u of SM_DATA[p]) changed = smTouch(sm, base + u, d) || changed;
  }
  for (const p of deletes) if (smKind(p) && !smExcluded(p, extra)) changed = smRemove(sm, smUrl(base, p)) || changed; // file bị xóa → bỏ URL khỏi sitemap
  return changed ? smBuild(sm) : null;
}
// Móc vào /commit: trả về hàm edit cho commitFiles. Lỗi sitemap không bao giờ chặn việc đăng bài.
const smEdit = (env, files, deletes, info) => async ({ head }) => {
  try {
    const [xml, S] = await Promise.all([readAt(env, "sitemap.xml", head), readSettingsAt(env, head)]);
    const out = smApplyCommit(xml, { files, deletes, base: siteBase(env, xml, S), extra: smExtra(S) });
    info.sitemap = out ? "updated" : "unchanged";
    return out ? [{ path: "sitemap.xml", content: out }] : null;
  } catch (e) { info.sitemap = "error: " + String(e.message || e).slice(0, 160); return null; }
};

export default {
  async fetch(req, rawEnv, ctx) {
    const env = cleanEnv(rawEnv);
    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors(env) });
    if (req.headers.get("Origin") && req.headers.get("Origin") !== env.ALLOWED_ORIGIN) return json(env, { error: "origin" }, 403);
    const url = new URL(req.url);
    try {
      if (url.pathname === "/login" && req.method === "POST") {
        const ip = req.headers.get("CF-Connecting-IP") || "?";
        const rec = failedLogins.get(ip) || { n: 0, until: 0 };
        if (rec.until > Date.now()) return json(env, { error: "Thử lại sau ít phút" }, 429);
        const { password } = await req.json().catch(() => ({}));
        if (!(await passwordOk(env, password ?? ""))) {
          rec.n += 1; if (rec.n >= 5) { rec.until = Date.now() + 10 * 60 * 1000; rec.n = 0; ctx.waitUntil(alertAdmin(env, req, "lock")); }
          failedLogins.set(ip, rec);
          await new Promise((r) => setTimeout(r, 700));
          return json(env, { error: "Sai mật khẩu" }, 401);
        }
        failedLogins.delete(ip);
        ctx.waitUntil(alertAdmin(env, req, "login"));
        return json(env, await makeToken(env));
      }

      if (!(await tokenOk(env, req))) return json(env, { error: "Chưa đăng nhập hoặc phiên hết hạn" }, 401);

      if (url.pathname === "/ping") {
        if (!url.searchParams.get("deep")) return json(env, { ok: true });
        const raw = String(rawEnv.GITHUB_TOKEN ?? ""), tk = env.GITHUB_TOKEN || ""; // chỉ cho biết dạng và độ dài, không lộ token
        const token = { present: !!tk, length: tk.length, removed: raw.length - tk.length, type: (tk.match(/^(github_pat_|ghp_|gho_|ghu_|ghs_|ghr_)/) || [""])[0] };
        try { // kiểm tra sâu: token GitHub có dùng được và có quyền ghi repo web không
          const br = env.GITHUB_BRANCH || "main", repo = await (await gh(env, repoBase(env))).json();
          await gh(env, `${repoBase(env)}/branches/${encodeURIComponent(br)}`);
          return json(env, { ok: true, token, github: { ok: true, repo: repo.full_name, branch: br, canPush: repo.permissions?.push } });
        } catch (e) { return json(env, { ok: true, token, github: { ok: false, error: String(e.message || e) } }); }
      }

      if (url.pathname === "/notify/test" && req.method === "POST") {
        if (!env.TELEGRAM_BOT_TOKEN || !env.TELEGRAM_CHAT_ID) return json(env, { error: "Chưa đặt TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID trong Worker" }, 501);
        return (await tg(env, "✅ Telegram đã kết nối với Shinju Admin")) ? json(env, { ok: true }) : json(env, { error: "Telegram từ chối (kiểm tra token và chat id)" }, 502);
      }

      if (url.pathname === "/tree") {
        const t = await (await gh(env, `${repoBase(env)}/git/trees/${env.GITHUB_BRANCH || "main"}?recursive=1`)).json();
        return json(env, { files: t.tree.filter((x) => x.type === "blob").map((x) => ({ path: x.path, size: x.size })) });
      }

      if (url.pathname === "/file") {
        const path = url.searchParams.get("path");
        if (!safePath(path)) return json(env, { error: "path" }, 400);
        const r = await gh(env, `${repoBase(env)}/contents/${path.split("/").map(encodeURIComponent).join("/")}?ref=${env.GITHUB_BRANCH || "main"}`, { accept: "application/vnd.github.raw+json" });
        return json(env, { path, content: await r.text() }); // chỉ dành cho file văn bản (md, json, html...)
      }

      if (url.pathname === "/commit" && req.method === "POST") {
        // Giới hạn bảo vệ Worker (gói Free: tối đa 50 lệnh gọi ra ngoài mỗi request, CPU rất ít)
        const maxBody = Number(env.MAX_BODY_BYTES) || 4000000, maxFiles = Number(env.MAX_FILES_PER_COMMIT) || 40;
        const tooBig = { error: `Dữ liệu quá lớn (tối đa ${Math.round(maxBody / 1e6)} MB mỗi lần). Giảm ảnh hoặc đăng từng phần.` };
        if (Number(req.headers.get("Content-Length")) > maxBody) return json(env, tooBig, 413);
        const raw = await req.text();
        if (raw.length > maxBody) return json(env, tooBig, 413);
        const { message, files = [], deletes = [] } = JSON.parse(raw);
        if (files.length + deletes.length > maxFiles) return json(env, { error: `Tối đa ${maxFiles} file mỗi lần commit` }, 413);
        if (Date.now() - lastCommit < 1500) return json(env, { error: "Thao tác quá nhanh, thử lại sau 2 giây" }, 429);
        lastCommit = Date.now();
        if (![...files.map((f) => f.path), ...deletes].every(safePath)) return json(env, { error: "path không hợp lệ" }, 400);
        if (!files.length && !deletes.length) return json(env, { error: "Không có thay đổi" }, 400);
        // Worker giữ sitemap.xml: bài/trang/ảnh thay đổi trong commit này → cập nhật sitemap cùng commit. (sitemap.xml do trang admin bản cũ gửi lên sẽ bị bỏ qua)
        const info = {}, useSm = smRelevant(files, deletes) && files.length + 9 <= (Number(env.SUBREQUEST_LIMIT) || 50);
        const sha = await commitFiles(env, { message: String(message || "Cập nhật từ trang admin").slice(0, 200), files: useSm ? files.filter((f) => f.path !== "sitemap.xml") : files, deletes, edit: useSm ? smEdit(env, files, deletes, info) : undefined });
        return json(env, { ok: true, sha, ...(info.sitemap ? { sitemap: info.sitemap } : {}) });
      }

      if (url.pathname === "/ai/seo" && req.method === "POST") {
        if (!env.AI) return json(env, { error: "Chưa bật Workers AI (binding AI)" }, 501);
        const { title = "", body = "" } = await req.json();
        const messages = [
          { role: "system", content: 'Bạn là chuyên gia SEO tiếng Việt. Chỉ trả về JSON: {"seoTitle":"<=60 ký tự","description":"<=155 ký tự","keywords":["5-10 từ khóa"]}. Không giải thích.' },
          { role: "user", content: `Tiêu đề: ${title}\n\n${String(body).slice(0, 6000)}` },
        ];
        // Cloudflare hay ngừng model cũ → thử lần lượt: model đặt trong AI_MODEL, rồi các model dự phòng. Model nào lỗi/ngừng thì bỏ qua.
        const models = [...new Set([env.AI_MODEL, ...AI_FALLBACKS].filter(Boolean))], errs = [];
        for (const model of models) {
          try {
            const txt = aiText(await env.AI.run(model, { max_tokens: 500, messages })), s0 = txt.indexOf("{"), e0 = txt.lastIndexOf("}");
            if (s0 >= 0 && e0 > s0) { try { return json(env, { ...JSON.parse(txt.slice(s0, e0 + 1)), model }); } catch (e) { /* sai JSON → thử model sau */ } }
            errs.push(`${model}: trả về sai định dạng`);
          } catch (err) { errs.push(`${model}: ${String(err.message || err).slice(0, 140)}`); }
        }
        return json(env, { error: "Không dùng được AI. " + errs.join(" | ") }, 502);
      }

      return json(env, { error: "not found" }, 404);
    } catch (err) {
      // 401 chỉ dành cho phiên admin. Lỗi 401/403 từ GitHub phải đổi sang 502, nếu không trang admin tưởng hết phiên và tự đăng xuất.
      if (err.github && err.status === 401) return json(env, { error: "GitHub từ chối token (401): GITHUB_TOKEN sai, hết hạn hoặc đã bị thu hồi. Tạo token mới (quyền Contents: Read and write cho repo web) rồi đặt lại secret." }, 502);
      if (err.github && err.status === 403) return json(env, { error: `GitHub từ chối quyền (403): token thiếu quyền Contents: Read and write cho repo này, hoặc bị giới hạn tốc độ. ${err.message}` }, 502);
      return json(env, { error: String(err.message || err) }, err.status && err.status >= 400 && err.status < 600 && err.status !== 401 ? err.status : 500);
    }
  },
  async scheduled(event, rawEnv, ctx) {
    const env = cleanEnv(rawEnv);
    // Chỉ còn cron mỗi giờ: kiểm tra mốc lượt xem/tải (không còn quét sitemap định kỳ)
    ctx.waitUntil(checkMilestones(env).catch(() => {}));
  },
};
