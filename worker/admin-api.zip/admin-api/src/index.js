// Shinju Admin API — Cloudflare Worker.
// Giữ GITHUB_TOKEN (quyền ghi repo web) ở phía server; trang /admin chỉ giữ phiên ngắn hạn.
const enc = new TextEncoder();
// Dán secret vào cmd đôi khi kèm ký tự điều khiển/khoảng trắng ẩn → lọc bỏ trước khi dùng.
const cleanSecret = (v) => String(v ?? "").replace(/\x1b\[[0-9;?]*[ -\/]*[@-~]/g, "").trim();
const cleanToken = (v) => cleanSecret(v).replace(/[^\x21-\x7e]/g, ""); // token GitHub/Telegram chỉ gồm ký tự ASCII in được
const TOKEN_KEYS = new Set(["GITHUB_TOKEN", "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID"]);
// Làm sạch TẤT CẢ biến/secret dạng chuỗi ngay khi nhận (dấu cách, xuống dòng, mã dán ẩn); binding như env.AI giữ nguyên.
function cleanEnv(env) {
  const o = { ...env };
  for (const [k, v] of Object.entries(env)) if (typeof v === "string") o[k] = TOKEN_KEYS.has(k) ? cleanToken(v) : cleanSecret(v);
  if (o.ALLOWED_ORIGIN) o.ALLOWED_ORIGIN = o.ALLOWED_ORIGIN.replace(/\/+$/, ""); // origin không có dấu / ở cuối
  return o;
}
const b64u = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const unb64u = (s) => Uint8Array.from(atob(s.replace(/-/g, "+").replace(/_/g, "/")), (c) => c.charCodeAt(0));

let lastCommit = 0; // chống bấm dồn dập (theo từng isolate)
const failedLogins = new Map(); // ip -> {n, until}  (theo từng isolate; bổ sung Rate Limiting Rule của Cloudflare để chắc hơn)

const cors = (env) => ({
  "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN,
  "Access-Control-Allow-Headers": "Authorization, Content-Type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Vary": "Origin",
});
const json = (env, data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store", ...cors(env) } });

async function hmacKey(env, usage) {
  return crypto.subtle.importKey("raw", enc.encode(env.SESSION_SECRET), { name: "HMAC", hash: "SHA-256" }, false, usage);
}
async function makeToken(env) {
  const exp = Math.floor(Date.now() / 1000) + (Number(env.SESSION_TTL_SECONDS) || 3600);
  const payload = b64u(enc.encode(JSON.stringify({ exp })));
  const sig = await crypto.subtle.sign("HMAC", await hmacKey(env, ["sign"]), enc.encode(payload));
  return { token: `${payload}.${b64u(sig)}`, exp };
}
async function tokenOk(env, req) {
  const m = (req.headers.get("Authorization") || "").match(/^Bearer (.+)\.(.+)$/);
  if (!m) return false;
  try {
    const good = await crypto.subtle.verify("HMAC", await hmacKey(env, ["verify"]), unb64u(m[2]), enc.encode(m[1]));
    return good && JSON.parse(new TextDecoder().decode(unb64u(m[1]))).exp > Date.now() / 1000;
  } catch { return false; }
}
async function passwordOk(env, given) {
  const [a, b] = await Promise.all([String(given).trim(), env.ADMIN_PASSWORD].map((v) => crypto.subtle.digest("SHA-256", enc.encode(v))));
  return crypto.subtle.timingSafeEqual(a, b);
}

// ---- GitHub ----
async function gh(env, path, { method = "GET", body, accept = "application/vnd.github+json" } = {}) {
  const res = await fetch(`https://api.github.com${path}`, {
    method,
    headers: { Authorization: `Bearer ${env.GITHUB_TOKEN}`, Accept: accept, "User-Agent": "shinju-admin-api", "X-GitHub-Api-Version": "2022-11-28", ...(body ? { "Content-Type": "application/json" } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) throw Object.assign(new Error(`GitHub ${res.status} (${method} ${path.replace(/\?.*$/, "")}): ${(await res.text()).slice(0, 300)}`), { status: res.status, github: true }); // ghi rõ yêu cầu nào bị từ chối để dễ tìm lỗi
  return res;
}
const repoBase = (env) => `/repos/${env.GITHUB_OWNER}/${env.GITHUB_REPO}`;
// Chặn đường dẫn nguy hiểm: thoát thư mục, .git, và workflow (tránh cài Actions lạ nếu lộ phiên).
const safePath = (p) => typeof p === "string" && p && !p.startsWith("/") && !p.split("/").some((s) => s === ".." || s === ".git") && !p.startsWith(".github/");

async function commitFiles(env, { message, files = [], deletes = [], edit }) {
  const base = repoBase(env), br = env.GITHUB_BRANCH || "main";
  const head = (await (await gh(env, `${base}/git/ref/heads/${br}`)).json()).object.sha;
  const parent = await (await gh(env, `${base}/git/commits/${head}`)).json();
  // edit({head, tree}) có thể trả thêm file (vd sitemap.xml). Nó đọc dữ liệu đúng tại commit cha `head`, còn bước PATCH ref bên dưới
  // không-force nên nếu có ai commit chen vào giữa thì báo lỗi, không bao giờ ghi đè mất thay đổi của người khác.
  if (edit) { const extra = await edit({ head, tree: parent.tree.sha }); if (extra?.length) files = files.concat(extra); }
  if (!files.length && !deletes.length) return null; // không có gì để ghi → không tạo commit rỗng (đỡ build lại GitHub Pages)
  const tree = [];
  for (const f of files) {
    const blob = await (await gh(env, `${base}/git/blobs`, { method: "POST", body: { content: f.content, encoding: f.encoding === "base64" ? "base64" : "utf-8" } })).json();
    tree.push({ path: f.path, mode: "100644", type: "blob", sha: blob.sha });
  }
  for (const p of deletes) tree.push({ path: p, mode: "100644", type: "blob", sha: null });
  const newTree = await (await gh(env, `${base}/git/trees`, { method: "POST", body: { base_tree: parent.tree.sha, tree } })).json();
  const c = await (await gh(env, `${base}/git/commits`, { method: "POST", body: { message, tree: newTree.sha, parents: [head] } })).json();
  await gh(env, `${base}/git/refs/heads/${br}`, { method: "PATCH", body: { sha: c.sha } }); // không force: có xung đột thì báo lỗi
  return c.sha;
}

// ---- Telegram: cảnh báo đăng nhập + mốc lượt xem/tải ----
const h = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
async function tg(env, text) {
  if (!env.TELEGRAM_BOT_TOKEN || !env.TELEGRAM_CHAT_ID) return false;
  const r = await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`, { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: env.TELEGRAM_CHAT_ID, text, parse_mode: "HTML", disable_web_page_preview: true }) });
  return r.ok;
}
async function readRepoJson(env, path, fallback) {
  try { return JSON.parse(await (await gh(env, `${repoBase(env)}/contents/${path}?ref=${env.GITHUB_BRANCH || "main"}`, { accept: "application/vnd.github.raw+json" })).text()); }
  catch (e) { if (e.status === 404 || e instanceof SyntaxError) return fallback; throw e; }
}
const readSettings = (env) => readRepoJson(env, "site-settings.json", {}).catch(() => ({}));
async function alertAdmin(env, req, kind) { // kind: "login" | "lock"
  try {
    const T = (await readSettings(env)).telegram || {};
    if (kind === "login" ? T.login === false : T.loginFail === false) return;
    const when = new Date().toLocaleString("vi-VN", { timeZone: "Asia/Ho_Chi_Minh" });
    const who = `🌐 IP: <code>${h(req.headers.get("CF-Connecting-IP") || "?")}</code> (${h(req.cf?.country || "?")})\n📱 ${h((req.headers.get("User-Agent") || "?").slice(0, 120))}`;
    await tg(env, kind === "login" ? `🔐 <b>Đăng nhập trang admin</b>\n🕒 ${when}\n${who}` : `⚠️ <b>Nhập sai mật khẩu admin 5 lần</b> — đã khóa 10 phút\n🕒 ${when}\n${who}`);
  } catch (e) { /* cảnh báo hỏng không được làm hỏng đăng nhập */ }
}
const parseTh = (v) => [...new Set((Array.isArray(v) ? v : String(v || "").split(/[,\s]+/)).map(Number).filter((n) => n > 0))].sort((a, b) => a - b);
const AI_FALLBACKS = ["@cf/meta/llama-3.3-70b-instruct-fp8-fast", "@cf/meta/llama-3.1-8b-instruct-fp8", "@cf/google/gemma-4-26b-a4b-it"]; // theo danh mục Workers AI (08/2026)
// Mỗi model trả về một kiểu: {response}, {choices:[{message}]}, ... → gom về chuỗi
const aiText = (o) => (typeof o === "string" ? o : o ? String(o.response ?? o.result?.response ?? o.choices?.[0]?.message?.content ?? o.output_text ?? "") : "");
const MAX_ITEMS = 35; // gói Free: tối đa 50 lệnh gọi ra ngoài mỗi lần chạy → giữ chỗ cho các lệnh khác
// Chạy theo giờ (Cron): so lượt xem/tải với các mốc đã đặt; mốc đã báo được lưu trong site-notify-state.json
async function checkMilestones(env) {
  const T = (await readSettings(env)).telegram || {};
  const vTh = T.views?.enabled ? parseTh(T.views.thresholds) : [], dTh = T.downloads?.enabled ? parseTh(T.downloads.thresholds) : [];
  if (!vTh.length && !dTh.length) return { skipped: true };
  const [posts, tree, state] = await Promise.all([readRepoJson(env, "post/data/posts.json", []), gh(env, `${repoBase(env)}/git/trees/${env.GITHUB_BRANCH || "main"}?recursive=1`).then((r) => r.json()), readRepoJson(env, "site-notify-state.json", {})]);
  const items = [];
  if (vTh.length) posts.filter((p) => p.visibility !== "private").forEach((p) => items.push({ key: "v:" + p.id, id: p.id, type: "view", field: "views", th: vTh, title: p.title }));
  if (dTh.length) tree.tree.map((x) => (x.path.match(/^download\/data\/([^/]+)\.json$/) || [])[1]).filter(Boolean).forEach((id) => items.push({ key: "d:" + id, id, type: "download", field: "downloads", th: dTh }));
  const repo = env.COUNTERS_REPO || `${env.GITHUB_OWNER}/api-counters`;
  const counts = await Promise.all(items.slice(0, MAX_ITEMS).map(async (it) => { try { const r = await fetch(`https://raw.githubusercontent.com/${repo}/main/${it.type}-${encodeURIComponent(it.id)}.json?t=${Date.now()}`); return r.ok ? (await r.json())[it.field] || 0 : 0; } catch (e) { return null; } }));
  const site = `https://${env.GITHUB_REPO}`; let changed = false, sent = 0;
  for (const [i, it] of items.slice(0, MAX_ITEMS).entries()) {
    const n = counts[i]; if (n == null) continue;
    const top = Math.max(0, ...it.th.filter((t) => n >= t));
    if (state[it.key] === undefined) { state[it.key] = top; changed = true; continue; } // lần đầu thấy mục này: chỉ ghi mốc, không báo mốc cũ
    if (top > state[it.key]) {
      let title = it.title;
      if (it.type === "download") title = (await readRepoJson(env, `download/data/${it.id}.json`, {}).catch(() => ({}))).title || it.id;
      const url = `${site}/${it.type === "view" ? "post" : "download"}/${encodeURIComponent(it.id)}/`;
      await tg(env, it.type === "view" ? `📈 Bài <b>${h(title)}</b> đã đạt <b>${top.toLocaleString("vi-VN")}</b> lượt xem\n${url}` : `⬇️ Mục tải <b>${h(title)}</b> đã đạt <b>${top.toLocaleString("vi-VN")}</b> lượt tải\n${url}`);
      state[it.key] = top; changed = true; sent++;
    }
  }
  if (changed) await commitFiles(env, { message: "Bot: cập nhật mốc thông báo Telegram", files: [{ path: "site-notify-state.json", content: JSON.stringify(state, null, 2) + "\n" }] });
  return { checked: Math.min(items.length, MAX_ITEMS), sent };
}

// ---- Sitemap: Worker giữ sitemap.xml ----
// Giới hạn Worker (gói Free) đã tính sẵn: tối đa 50 lệnh gọi ra ngoài + ~10 ms CPU mỗi lần chạy.
//  • Không còn chức năng quét toàn repo / cron quét sitemap: sitemap chỉ được cập nhật theo từng commit từ trang admin.
//  • Chỉ dùng chuỗi/regex trên dữ liệu đã tải (không có bộ đọc XML nặng); không có URL mới thì không commit.
//  • Mỗi lần /commit của trang admin tốn thêm 2 lệnh đọc (sitemap + cài đặt); tự bỏ qua nếu sẽ vượt giới hạn lệnh gọi.
const SM_HEAD = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
const SM_MAX = 50000; // giới hạn của giao thức sitemap: 50.000 URL mỗi file
const SM_IMG = /\.(png|jpe?g|webp|gif|avif|svg|bmp)$/i, SM_DOC = /\.pdf$/i; // chỉ file xem được công khai; .js/.css/.json/.md/... không bao giờ vào sitemap
const SM_SKIP = ["admin/", "buy/", "s/", "assets/favicon/", "assets/donate/", "node_modules/", "donate/overlay/", "donate/media/"]; // s/ = trang chuyển hướng (noindex); favicon/QR không cần Google Images. Thêm bớt qua site-settings.json → sitemap.exclude
// Trang không có file index.html riêng nhưng đổi dữ liệu thì đổi nội dung trang → đặt lastmod hôm nay
const SM_DATA = { "channel/data.json": ["/channel/"], "donate/data.json": ["/donate/"], "data.json": ["/"], "post/data/posts.json": ["/post/", "/"] };
const smToday = () => new Date(Date.now() + 7 * 3600 * 1000).toISOString().slice(0, 10); // ngày theo giờ Việt Nam
const xmlEsc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const xmlUnesc = (s) => String(s).replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&");
const canon = (u) => { try { return decodeURI(u); } catch (e) { return u; } }; // so khớp URL không phân biệt %-mã hóa
const smKind = (p) => (/(^|\/)index\.html$/.test(p) ? "page" : SM_IMG.test(p) ? "image" : SM_DOC.test(p) ? "doc" : null);
const smExcluded = (p, extra = []) => p.split("/").some((s) => s.startsWith(".") || s === "node_modules") || [...SM_SKIP, ...extra].some((x) => p.startsWith(x));
const smExtra = (s) => (Array.isArray(s?.sitemap?.exclude) ? s.sitemap.exclude : []).map((x) => String(x).replace(/^\/+/, "")).filter(Boolean);
// dir/index.html → /dir/ (không kèm index.html) ; ảnh → /đường/dẫn.webp
const smUrl = (base, p) => { const m = p.match(/^(?:(.*)\/)?index\.html$/); return base + (m ? (m[1] ? "/" + m[1].split("/").map(encodeURIComponent).join("/") + "/" : "/") : "/" + p.split("/").map(encodeURIComponent).join("/")); };
const siteBase = (env, xml, S) => String(env.SITE_URL || S?.seo?.siteUrl || (String(xml).match(/<loc>\s*(https?:\/\/[^/<\s]+)/) || [])[1] || `https://${env.GITHUB_REPO}`).replace(/\/+$/, "");

// Đọc file văn bản tại một commit cụ thể; không có file → ""
async function readAt(env, path, ref) {
  try { return await (await gh(env, `${repoBase(env)}/contents/${path.split("/").map(encodeURIComponent).join("/")}?ref=${ref}`, { accept: "application/vnd.github.raw+json" })).text(); }
  catch (e) { if (e.status === 404) return ""; throw e; }
}
const readSettingsAt = async (env, ref) => { try { return JSON.parse((await readAt(env, "site-settings.json", ref)) || "{}"); } catch (e) { return {}; } };

function smParse(xml) {
  xml = String(xml || ""); const re = /<url>[\s\S]*?<\/url>/g, entries = []; let first = -1, m;
  while ((m = re.exec(xml))) { if (first < 0) first = m.index; const loc = (m[0].match(/<loc>\s*([^<]*?)\s*<\/loc>/) || [])[1]; entries.push({ key: loc == null ? null : canon(xmlUnesc(loc)), raw: m[0] }); }
  return { head: first < 0 ? SM_HEAD : xml.slice(0, first).replace(/\s+$/, ""), eol: xml.includes("\r\n") ? "\r\n" : "\n", entries, map: new Map(entries.filter((e) => e.key).map((e) => [e.key, e])) };
}
// Mục chưa đổi giữ nguyên từng byte; mục khác (kể cả thẻ lạ như <image:image>) không bị đụng tới
const smBuild = (sm) => sm.head + sm.eol + sm.entries.map((e) => "  " + e.raw + sm.eol).join("") + "</urlset>" + sm.eol;
function smAdd(sm, loc, d) { // chỉ thêm khi CHƯA có; mục đã có giữ nguyên, kể cả lastmod
  const key = canon(loc); if (sm.map.has(key) || sm.entries.length >= SM_MAX) return false;
  const e = { key, raw: `<url><loc>${xmlEsc(loc)}</loc>${d ? `<lastmod>${d}</lastmod>` : ""}</url>` };
  sm.entries.push(e); sm.map.set(key, e); return true;
}
function smTouch(sm, loc, d) { // đặt lastmod = d (thêm mới nếu chưa có)
  const e = sm.map.get(canon(loc)); if (!e) return smAdd(sm, loc, d);
  const next = /<lastmod>/.test(e.raw) ? e.raw.replace(/<lastmod>[^<]*<\/lastmod>/, `<lastmod>${d}</lastmod>`) : e.raw.replace("</loc>", `</loc><lastmod>${d}</lastmod>`);
  if (next === e.raw) return false; e.raw = next; return true;
}
function smRemove(sm, loc) {
  const key = canon(loc), e = sm.map.get(key); if (!e) return false;
  sm.map.delete(key); sm.entries.splice(sm.entries.indexOf(e), 1); return true;
}
const smRelevant = (files, deletes) => [...files.map((f) => f.path), ...deletes].some((p) => smKind(p) || SM_DATA[p]);

// Áp thay đổi của MỘT commit lên sitemap. Trả về nội dung mới, hoặc null nếu không có gì đổi.
function smApplyCommit(xml, { files, deletes, base, extra }) {
  const sm = smParse(xml), d = smToday(); let changed = false;
  const paths = files.map((f) => f.path).filter((p) => !smExcluded(p, extra));
  // Một lần đăng/sửa chỉ ghi 1 trang bài/mục tải. Nhiều hơn = tạo lại hàng loạt → chỉ thêm mục còn thiếu, không đổi lastmod mục đã có
  const bulk = paths.filter((p) => /^(post|download)\/[^/]+\/index\.html$/.test(p)).length > 1;
  for (const p of paths) {
    const k = smKind(p);
    if (k === "page") changed = (bulk ? smAdd(sm, smUrl(base, p), d) : smTouch(sm, smUrl(base, p), d)) || changed; // trang đổi → lastmod hôm nay
    else if (k) changed = smAdd(sm, smUrl(base, p), d) || changed; // ảnh/pdf: có rồi thì không thêm, không đổi lastmod
    else if (SM_DATA[p] && !bulk) for (const u of SM_DATA[p]) changed = smTouch(sm, base + u, d) || changed;
  }
  for (const p of deletes) if (smKind(p) && !smExcluded(p, extra)) changed = smRemove(sm, smUrl(base, p)) || changed; // file bị xóa → bỏ URL khỏi sitemap
  return changed ? smBuild(sm) : null;
}
// Móc vào /commit: trả về hàm edit cho commitFiles. Lỗi sitemap không bao giờ chặn việc đăng bài.
const smEdit = (env, files, deletes, info) => async ({ head }) => {
  try {
    const [xml, S] = await Promise.all([readAt(env, "sitemap.xml", head), readSettingsAt(env, head)]);
    const out = smApplyCommit(xml, { files, deletes, base: siteBase(env, xml, S), extra: smExtra(S) });
    info.sitemap = out ? "updated" : "unchanged";
    return out ? [{ path: "sitemap.xml", content: out }] : null;
  } catch (e) { info.sitemap = "error: " + String(e.message || e).slice(0, 160); return null; }
};

// ======================= BÁN MODEL BẰNG MÃ TẢI =======================
// Luồng: admin tạo mã (lưu KV "BUY") → khách dán mã ở /buy/ → Worker cấp "vé" ký HMAC sống 5 phút →
// trình duyệt mở /buy/dl?t=vé → Worker lấy file từ release của repo PRIVATE rồi truyền thẳng cho khách (không lộ link GitHub).
// Lượt tải chỉ bị trừ khi luồng dữ liệu chạy HẾT; ngắt giữa chừng thì không mất lượt.
// Giới hạn KV gói Free: 1.000 lượt ghi/ngày. Mỗi đơn tốn ~3 lượt ghi (tạo mã, bắt đầu tải, tải xong). Nhập sai mã KHÔNG ghi KV.
const CODE_ALPHABET = "23456789ABCDEFGHJKMNPQRSTUVWXYZ"; // 31 ký tự, bỏ 0 O 1 I L cho khỏi nhầm → 15 ký tự ≈ 74 bit
const CODE_LEN = 15;
const TICKET_TTL = 300; // giây: vé tải sống 5 phút
const LOCK_MS = 20 * 60 * 1000; // một mã chỉ tải 1 luồng một lúc; khoá tự nhả sau 20 phút nếu có sự cố
const buyFails = new Map(); // ip -> {n, until}  (theo từng isolate, giống đăng nhập admin; nên thêm Rate Limiting Rule của Cloudflare)

function randStr(n, alpha) {
  const lim = 256 - (256 % alpha.length), out = [];
  while (out.length < n) for (const x of crypto.getRandomValues(new Uint8Array(n * 2))) if (x < lim && out.length < n) out.push(alpha[x % alpha.length]);
  return out.join("");
}
// Dán từ Zalo/Messenger hay dính dấu cách, xuống dòng, dấu gạch lạ → bỏ hết, chỉ giữ chữ + số. Dán cả câu thì tìm đúng 3 nhóm 5 ký tự.
function normCode(s) {
  const up = String(s ?? "").toUpperCase(), flat = up.replace(/[^A-Z0-9]/g, "");
  if (flat.length === CODE_LEN) return flat;
  const m = up.match(/([2-9A-HJ-NP-Z]{5})[\s\-_.]*([2-9A-HJ-NP-Z]{5})[\s\-_.]*([2-9A-HJ-NP-Z]{5})/);
  return m ? m[1] + m[2] + m[3] : flat;
}
const fmtCode = (c) => String(c).match(/.{1,5}/g).join("-");
const clampInt = (v, lo, hi, d) => { v = Math.floor(Number(v)); return Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : d; };
const safeName = (s) => String(s || "file").normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D").replace(/[^A-Za-z0-9._-]+/g, "_").replace(/^[_.]+|_+$/g, "").slice(0, 100) || "file";
const contentDisp = (name) => `attachment; filename="${safeName(name)}"; filename*=UTF-8''${encodeURIComponent(name).replace(/['()*]/g, (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase())}`;
// "Model A.zip" → "Model A-k3x9p2.zip": tên gốc + hậu tố ngẫu nhiên cho mỗi lần tải
function randomizedName(file) {
  const m = String(file).match(/^(.*?)(\.[A-Za-z0-9]{1,10})?$/), base = (m[1] || "file").trim() || "file";
  return `${base}-${randStr(6, "abcdefghjkmnpqrstuvwxyz23456789")}${m[2] || ""}`;
}

const kvNeed = (env) => { if (!env.BUY) throw Object.assign(new Error("Chưa gắn KV namespace tên BUY cho Worker (xem README, mục Bán model)"), { status: 501 }); };
const relNeed = (env) => { if (!env.RELEASE_REPO) throw Object.assign(new Error("Chưa đặt biến RELEASE_REPO trong wrangler.toml (repo private chứa file bán)"), { status: 501 }); };

// ---- lưu trữ ----
const codeMeta = (r) => ({ p: r.product, m: r.max, u: r.used, s: r.status, e: r.exp || 0, c: r.created, l: r.lock || 0, n: String(r.note || "").slice(0, 80) });
const getCode = (env, code) => env.BUY.get("c:" + code, "json");
const saveCode = (env, r) => env.BUY.put("c:" + r.code, JSON.stringify(r), { metadata: codeMeta(r) });
const getProduct = (env, id) => env.BUY.get("p:" + id, "json");
const saveProduct = (env, p) => env.BUY.put("p:" + p.id, JSON.stringify(p), { metadata: { n: p.name.slice(0, 100), f: p.file.slice(0, 120), s: p.asset.size, a: p.asset.id, t: p.created } });
const codeState = (r, now = Date.now()) => (r.status === "revoked" ? "revoked" : r.exp && r.exp < now ? "expired" : r.used >= r.max ? "used" : r.lock > now ? "downloading" : "active");

// ---- vé tải (HMAC; thêm tiền tố "buy." để vé không bao giờ lẫn với phiên đăng nhập admin) ----
async function signTicket(env, obj) {
  const payload = b64u(enc.encode(JSON.stringify(obj)));
  return `${payload}.${b64u(await crypto.subtle.sign("HMAC", await hmacKey(env, ["sign"]), enc.encode("buy." + payload)))}`;
}
async function readTicket(env, t) {
  const m = String(t || "").match(/^([\w-]+)\.([\w-]+)$/);
  if (!m) return null;
  try {
    if (!(await crypto.subtle.verify("HMAC", await hmacKey(env, ["verify"]), unb64u(m[2]), enc.encode("buy." + m[1])))) return null;
    const p = JSON.parse(new TextDecoder().decode(unb64u(m[1])));
    return p.a === "dl" && p.e > Date.now() / 1000 ? p : null;
  } catch { return null; }
}

// ---- GitHub: release của repo private ----
async function ensureRelease(env) {
  relNeed(env);
  const base = `/repos/${env.RELEASE_REPO}`, tag = env.RELEASE_TAG || "models";
  try { return await (await gh(env, `${base}/releases/tags/${encodeURIComponent(tag)}`)).json(); }
  catch (e) { if (e.status !== 404) throw e; }
  return await (await gh(env, `${base}/releases`, { method: "POST", body: { tag_name: tag, name: "Kho model (private)", body: "Kho file bán hàng. Đừng xoá release này.", draft: false, prerelease: false } })).json();
}
async function ghUpload(env, releaseId, assetName, stream, len) {
  let body = stream;
  try { const fl = new FixedLengthStream(len); stream.pipeTo(fl.writable).catch(() => {}); body = fl.readable; } catch { /* môi trường không có FixedLengthStream → để runtime tự xử lý */ }
  const res = await fetch(`https://uploads.github.com/repos/${env.RELEASE_REPO}/releases/${releaseId}/assets?name=${encodeURIComponent(assetName)}`, {
    method: "POST", body,
    headers: { Authorization: `Bearer ${env.GITHUB_TOKEN}`, Accept: "application/vnd.github+json", "User-Agent": "shinju-admin-api", "X-GitHub-Api-Version": "2022-11-28", "Content-Type": "application/octet-stream", "Content-Length": String(len) },
  });
  if (!res.ok) throw Object.assign(new Error(`GitHub ${res.status} (upload asset): ${(await res.text()).slice(0, 300)}`), { status: res.status, github: true });
  return res.json();
}
// Lấy file: GitHub trả 302 tới link ký sẵn (sống vài phút, không cần token). KHÔNG gửi token sang host đó.
async function fetchAsset(env, assetId) {
  const r = await fetch(`https://api.github.com/repos/${env.RELEASE_REPO}/releases/assets/${assetId}`, {
    headers: { Authorization: `Bearer ${env.GITHUB_TOKEN}`, Accept: "application/octet-stream", "User-Agent": "shinju-admin-api", "X-GitHub-Api-Version": "2022-11-28" }, redirect: "manual",
  });
  if (r.status >= 300 && r.status < 400 && r.headers.get("Location")) return fetch(r.headers.get("Location"));
  return r;
}

// ---- công khai: /buy/* ----
const htmlMsg = (status, title, text) => new Response(`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${h(title)}</title><body style="font:16px system-ui;background:#050b16;color:#f4ecd8;display:grid;place-items:center;min-height:100vh;margin:0;padding:20px;text-align:center"><div><h2>${h(title)}</h2><p>${h(text)}</p></div>`, { status, headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" } });
const failedBlocked = (req) => (buyFails.get(req.headers.get("CF-Connecting-IP") || "?")?.until || 0) > Date.now();
function markFail(req) {
  const ip = req.headers.get("CF-Connecting-IP") || "?", rec = buyFails.get(ip) || { n: 0, until: 0 };
  rec.n += 1; if (rec.n >= 10) { rec.until = Date.now() + 15 * 60 * 1000; rec.n = 0; }
  buyFails.set(ip, rec);
  if (buyFails.size > 2000) for (const [k, v] of buyFails) if (v.until < Date.now() && !v.n) buyFails.delete(k);
}
const BAD_STATE = { revoked: "Mã này đã bị thu hồi. Liên hệ người bán nếu bạn nghĩ đây là nhầm lẫn.", expired: "Mã này đã hết hạn. Liên hệ người bán để được hỗ trợ.", used: "Mã này đã dùng hết lượt tải. Liên hệ người bán nếu bạn cần tải lại." };

async function buyPublic(env, req, ctx, url) {
  try {
    kvNeed(env);
    if (url.pathname === "/buy/dl" && req.method === "GET") return await buyDownload(env, req, ctx, url); // mở bằng thanh địa chỉ → không có Origin; được bảo vệ bằng vé ký
    if (!env.ALLOWED_ORIGINS.includes(req.headers.get("Origin") || "")) return json(env, { error: "origin" }, 403); // các route còn lại: bắt buộc gọi từ trang của bạn
    if (url.pathname === "/buy/redeem" && req.method === "POST") return await buyRedeem(env, req);
    if (url.pathname === "/buy/status" && req.method === "GET") return await buyStatus(env, url);
    return json(env, { error: "not found" }, 404);
  } catch (e) { console.error("buy:", e.message || e); return json(env, { error: "Hệ thống đang lỗi, thử lại sau ít phút hoặc nhắn người bán." }, 500); }
}

async function buyRedeem(env, req) {
  if (failedBlocked(req)) return json(env, { error: "Nhập sai quá nhiều lần. Thử lại sau 15 phút." }, 429);
  const raw = (await req.text()).slice(0, 600);
  let body = {}; try { body = JSON.parse(raw); } catch { /* để trống */ }
  const code = normCode(body.code);
  const rec = code.length === CODE_LEN ? await getCode(env, code) : null;
  if (!rec) { markFail(req); await new Promise((r) => setTimeout(r, 600)); return json(env, { error: "Mã không đúng. Kiểm tra lại mã người bán gửi cho bạn." }, 404); }
  const st = codeState(rec);
  if (BAD_STATE[st]) return json(env, { error: BAD_STATE[st], state: st }, 403);
  const prod = await getProduct(env, rec.product);
  if (!prod) return json(env, { error: "Sản phẩm này hiện không còn trong kho. Liên hệ người bán." }, 410);
  const filename = randomizedName(prod.file);
  const ticket = await signTicket(env, { a: "dl", k: code, f: filename, e: Math.floor(Date.now() / 1000) + TICKET_TTL });
  return json(env, { ok: true, product: { name: prod.name, size: prod.asset.size }, filename, ticket, ttl: TICKET_TTL, used: rec.used, max: rec.max, remaining: rec.max - rec.used, state: st, exp: rec.exp || 0 });
}

async function buyStatus(env, url) {
  const t = await readTicket(env, url.searchParams.get("t"));
  if (!t) return json(env, { error: "Vé tải đã hết hạn", expired: true }, 403);
  const rec = await getCode(env, t.k);
  if (!rec) return json(env, { error: "not found" }, 404);
  return json(env, { state: codeState(rec), dl: rec.dl?.state || null, used: rec.used, max: rec.max, remaining: rec.max - rec.used });
}

async function buyDownload(env, req, ctx, url) {
  const t = await readTicket(env, url.searchParams.get("t"));
  if (!t) return htmlMsg(403, "Link tải đã hết hạn", "Quay lại trang nhận file và dán mã lại để lấy link mới (không mất lượt tải).");
  const rec = await getCode(env, t.k);
  if (!rec) return htmlMsg(404, "Không tìm thấy mã", "Liên hệ người bán.");
  const st = codeState(rec);
  if (st === "downloading") return htmlMsg(409, "Mã đang được tải", "Đang có một lượt tải khác chạy với mã này. Chờ nó xong (hoặc tối đa 20 phút) rồi thử lại.");
  if (st !== "active") return htmlMsg(403, "Không tải được", BAD_STATE[st] || "Mã không còn dùng được.");
  const prod = await getProduct(env, rec.product);
  if (!prod) return htmlMsg(410, "Sản phẩm không còn", "Liên hệ người bán.");

  rec.lock = Date.now() + LOCK_MS; rec.dl = { state: "downloading", at: Date.now() };
  await saveCode(env, rec);
  const ip = req.headers.get("CF-Connecting-IP") || "?";
  const release = (ok) => finishDownload(env, rec.code, ok, prod, ip).catch((e) => console.error("finish:", e.message || e));
  let up;
  try { up = await fetchAsset(env, prod.asset.id); } catch (e) { console.error("asset:", e.message || e); }
  if (!up || !up.ok || !up.body) { ctx.waitUntil(release(false)); return htmlMsg(502, "Kho file đang lỗi", "Chưa mất lượt tải của bạn. Thử lại sau ít phút hoặc nhắn người bán."); }

  const len = Number(up.headers.get("Content-Length")) || 0;
  let ts; try { ts = len ? new FixedLengthStream(len) : new TransformStream(); } catch { ts = new TransformStream(); }
  // pipeTo chỉ xong khi toàn bộ dữ liệu đã được trình duyệt nhận hết; khách ngắt giữa chừng → bị từ chối → không trừ lượt
  ctx.waitUntil(up.body.pipeTo(ts.writable).then(() => release(true), () => release(false)));
  return new Response(ts.readable, { headers: { "Content-Type": "application/octet-stream", "Content-Disposition": contentDisp(String(t.f || "model.zip")), "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", ...(len ? { "Content-Length": String(len) } : {}) } });
}

async function finishDownload(env, code, ok, prod, ip) {
  const rec = await getCode(env, code); // đọc lại bản mới nhất (admin có thể vừa thu hồi/sửa)
  if (!rec) return;
  rec.lock = 0;
  if (ok) { rec.used = (rec.used || 0) + 1; rec.last = Date.now(); rec.dl = { state: "done", at: Date.now() }; }
  else rec.dl = { state: "failed", at: Date.now() };
  await saveCode(env, rec);
  if (ok) await tg(env, `⬇️ <b>Khách đã tải xong</b>\n📦 ${h(prod.name)}\n🔑 <code>${fmtCode(code)}</code> · còn ${Math.max(0, rec.max - rec.used)}/${rec.max} lượt${rec.note ? `\n📝 ${h(rec.note)}` : ""}\n🌐 ${h(ip)}`).catch(() => {});
}

// ---- quản trị: /buy-admin/* (đã qua cổng đăng nhập) ----
async function buyAdmin(env, req, url) {
  kvNeed(env);
  const p = url.pathname.slice("/buy-admin".length), post = req.method === "POST";
  const body = async () => { try { return JSON.parse((await req.text()).slice(0, 20000)); } catch { return {}; } };

  if (p === "/check") {
    const out = { kv: true, releaseRepo: env.RELEASE_REPO || null, tag: env.RELEASE_TAG || "models", origins: env.ALLOWED_ORIGINS, maxUpload: Number(env.MAX_UPLOAD_BYTES) || 95e6 };
    if (!env.RELEASE_REPO) { out.release = { ok: false, error: "Chưa đặt biến RELEASE_REPO" }; return json(env, out); }
    try {
      const r = await (await gh(env, `/repos/${env.RELEASE_REPO}`)).json();
      out.release = { ok: true, repo: r.full_name, private: r.private, canPush: r.permissions?.push };
      try { await gh(env, `/repos/${env.RELEASE_REPO}/releases/tags/${encodeURIComponent(out.tag)}`); out.release.hasTag = true; } catch (e) { out.release.hasTag = e.status === 404 ? false : null; }
    } catch (e) { out.release = { ok: false, error: String(e.message || e) }; }
    return json(env, out);
  }

  if (p === "/overview") {
    const cursor = url.searchParams.get("cursor") || undefined;
    const [pl, cl] = await Promise.all([env.BUY.list({ prefix: "p:" }), env.BUY.list({ prefix: "c:", limit: 1000, cursor })]);
    return json(env, {
      products: pl.keys.map((k) => ({ id: k.name.slice(2), name: k.metadata?.n, file: k.metadata?.f, size: k.metadata?.s, asset: k.metadata?.a, created: k.metadata?.t })),
      codes: cl.keys.map((k) => ({ code: k.name.slice(2), ...(k.metadata || {}) })),
      cursor: cl.list_complete ? null : cl.cursor,
    });
  }

  if (p === "/assets") {
    const rel = await ensureRelease(env);
    const list = await (await gh(env, `/repos/${env.RELEASE_REPO}/releases/${rel.id}/assets?per_page=100`)).json();
    return json(env, { assets: list.map((a) => ({ id: a.id, name: a.name, size: a.size })) });
  }

  if (p === "/product/upload" && post) {
    const name = (url.searchParams.get("name") || "").trim().slice(0, 100), file = (url.searchParams.get("file") || "").trim().slice(0, 200);
    const len = Number(req.headers.get("Content-Length")) || 0, max = Number(env.MAX_UPLOAD_BYTES) || 95e6;
    if (!name || !file) return json(env, { error: "Thiếu tên sản phẩm hoặc tên file" }, 400);
    if (!len || !req.body) return json(env, { error: "File rỗng" }, 400);
    if (len > max) return json(env, { error: `File ${(len / 1e6).toFixed(1)} MB vượt giới hạn ${(max / 1e6).toFixed(0)} MB của Cloudflare. Tải file lên release bằng GitHub rồi dùng mục "Dùng tệp đã có trong release".` }, 413);
    const id = randStr(8, "abcdefghijklmnopqrstuvwxyz0123456789"), rel = await ensureRelease(env);
    const a = await ghUpload(env, rel.id, `${id}-${safeName(file)}`, req.body, len);
    const product = { id, name, file, asset: { id: a.id, name: a.name, size: a.size }, created: Date.now() };
    await saveProduct(env, product);
    return json(env, { ok: true, product });
  }

  if (p === "/product/link" && post) {
    relNeed(env);
    const { name, assetId } = await body();
    if (!String(name || "").trim() || !assetId) return json(env, { error: "Thiếu tên hoặc tệp" }, 400);
    const a = await (await gh(env, `/repos/${env.RELEASE_REPO}/releases/assets/${Number(assetId)}`)).json();
    const product = { id: randStr(8, "abcdefghijklmnopqrstuvwxyz0123456789"), name: String(name).trim().slice(0, 100), file: a.name, asset: { id: a.id, name: a.name, size: a.size }, created: Date.now() };
    await saveProduct(env, product);
    return json(env, { ok: true, product });
  }

  if (p === "/product/rename" && post) {
    const { id, name } = await body(), prod = await getProduct(env, String(id || ""));
    if (!prod || !String(name || "").trim()) return json(env, { error: "Không tìm thấy sản phẩm" }, 404);
    prod.name = String(name).trim().slice(0, 100); await saveProduct(env, prod);
    return json(env, { ok: true });
  }

  if (p === "/product/delete" && post) {
    const { id, deleteAsset } = await body(), prod = await getProduct(env, String(id || ""));
    if (!prod) return json(env, { error: "Không tìm thấy sản phẩm" }, 404);
    await env.BUY.delete("p:" + prod.id);
    let assetDeleted = false;
    if (deleteAsset) { try { await gh(env, `/repos/${env.RELEASE_REPO}/releases/assets/${prod.asset.id}`, { method: "DELETE" }); assetDeleted = true; } catch (e) { if (e.status !== 404) throw e; assetDeleted = true; } }
    return json(env, { ok: true, assetDeleted });
  }

  if (p === "/codes/create" && post) {
    const b = await body(), prod = await getProduct(env, String(b.product || ""));
    if (!prod) return json(env, { error: "Chọn sản phẩm" }, 404);
    const n = clampInt(b.count, 1, 20, 1), max = clampInt(b.max, 1, 10, 2), days = clampInt(b.days, 0, 365, 0), now = Date.now();
    const recs = Array.from({ length: n }, () => ({ code: randStr(CODE_LEN, CODE_ALPHABET), product: prod.id, max, used: 0, status: "active", exp: days ? now + days * 86400000 : 0, created: now, note: String(b.note || "").trim().slice(0, 200), lock: 0 }));
    await Promise.all(recs.map((r) => saveCode(env, r)));
    return json(env, { ok: true, product: { id: prod.id, name: prod.name }, codes: recs.map((r) => fmtCode(r.code)), max, exp: recs[0].exp });
  }

  if (p === "/code" && post) {
    const b = await body(), code = normCode(b.code), rec = code.length === CODE_LEN ? await getCode(env, code) : null;
    if (!rec) return json(env, { error: "Không tìm thấy mã" }, 404);
    const a = b.action;
    if (a === "delete") { await env.BUY.delete("c:" + code); return json(env, { ok: true, deleted: true }); }
    if (a === "revoke") rec.status = "revoked";
    else if (a === "restore") rec.status = "active";
    else if (a === "plus") rec.max += clampInt(b.n, 1, 10, 1);
    else if (a === "unlock") rec.lock = 0;
    else if (a === "expiry") rec.exp = clampInt(b.days, 0, 365, 0) ? Date.now() + clampInt(b.days, 0, 365, 0) * 86400000 : 0;
    else if (a === "note") rec.note = String(b.note || "").trim().slice(0, 200);
    else return json(env, { error: "action" }, 400);
    await saveCode(env, rec);
    return json(env, { ok: true, code: { code, ...codeMeta(rec) } });
  }

  return json(env, { error: "not found" }, 404);
}

export default {
  async fetch(req, rawEnv, ctx) {
    const env = cleanEnv(rawEnv);
    // ALLOWED_ORIGIN có thể là một danh sách ngăn cách bằng dấu phẩy (đổi username/tên miền: thêm địa chỉ mới vào, giữ địa chỉ cũ một thời gian).
    env.ALLOWED_ORIGINS = String(env.ALLOWED_ORIGIN || "").split(",").map((s) => s.trim().replace(/\/+$/, "")).filter(Boolean);
    env.ALLOWED_ORIGIN = env.ALLOWED_ORIGINS.includes(req.headers.get("Origin")) ? req.headers.get("Origin") : env.ALLOWED_ORIGINS[0] || "";
    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors(env) });
    if (req.headers.get("Origin") && req.headers.get("Origin") !== env.ALLOWED_ORIGIN) return json(env, { error: "origin" }, 403);
    const url = new URL(req.url);
    if (url.pathname.startsWith("/buy/")) return buyPublic(env, req, ctx, url); // công khai: khách dán mã để tải
    try {
      if (url.pathname === "/login" && req.method === "POST") {
        const ip = req.headers.get("CF-Connecting-IP") || "?";
        const rec = failedLogins.get(ip) || { n: 0, until: 0 };
        if (rec.until > Date.now()) return json(env, { error: "Thử lại sau ít phút" }, 429);
        const { password } = await req.json().catch(() => ({}));
        if (!(await passwordOk(env, password ?? ""))) {
          rec.n += 1; if (rec.n >= 5) { rec.until = Date.now() + 10 * 60 * 1000; rec.n = 0; ctx.waitUntil(alertAdmin(env, req, "lock")); }
          failedLogins.set(ip, rec);
          await new Promise((r) => setTimeout(r, 700));
          return json(env, { error: "Sai mật khẩu" }, 401);
        }
        failedLogins.delete(ip);
        ctx.waitUntil(alertAdmin(env, req, "login"));
        return json(env, await makeToken(env));
      }

      if (!(await tokenOk(env, req))) return json(env, { error: "Chưa đăng nhập hoặc phiên hết hạn" }, 401);

      if (url.pathname.startsWith("/buy-admin/")) return await buyAdmin(env, req, url);

      if (url.pathname === "/ping") {
        if (!url.searchParams.get("deep")) return json(env, { ok: true });
        const raw = String(rawEnv.GITHUB_TOKEN ?? ""), tk = env.GITHUB_TOKEN || ""; // chỉ cho biết dạng và độ dài, không lộ token
        const token = { present: !!tk, length: tk.length, removed: raw.length - tk.length, type: (tk.match(/^(github_pat_|ghp_|gho_|ghu_|ghs_|ghr_)/) || [""])[0] };
        try { // kiểm tra sâu: token GitHub có dùng được và có quyền ghi repo web không
          const br = env.GITHUB_BRANCH || "main", repo = await (await gh(env, repoBase(env))).json();
          await gh(env, `${repoBase(env)}/branches/${encodeURIComponent(br)}`);
          return json(env, { ok: true, token, github: { ok: true, repo: repo.full_name, branch: br, canPush: repo.permissions?.push } });
        } catch (e) { return json(env, { ok: true, token, github: { ok: false, error: String(e.message || e) } }); }
      }

      if (url.pathname === "/notify/test" && req.method === "POST") {
        if (!env.TELEGRAM_BOT_TOKEN || !env.TELEGRAM_CHAT_ID) return json(env, { error: "Chưa đặt TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID trong Worker" }, 501);
        return (await tg(env, "✅ Telegram đã kết nối với Shinju Admin")) ? json(env, { ok: true }) : json(env, { error: "Telegram từ chối (kiểm tra token và chat id)" }, 502);
      }

      if (url.pathname === "/tree") {
        const t = await (await gh(env, `${repoBase(env)}/git/trees/${env.GITHUB_BRANCH || "main"}?recursive=1`)).json();
        return json(env, { files: t.tree.filter((x) => x.type === "blob").map((x) => ({ path: x.path, size: x.size })) });
      }

      if (url.pathname === "/file") {
        const path = url.searchParams.get("path");
        if (!safePath(path)) return json(env, { error: "path" }, 400);
        const r = await gh(env, `${repoBase(env)}/contents/${path.split("/").map(encodeURIComponent).join("/")}?ref=${env.GITHUB_BRANCH || "main"}`, { accept: "application/vnd.github.raw+json" });
        return json(env, { path, content: await r.text() }); // chỉ dành cho file văn bản (md, json, html...)
      }

      if (url.pathname === "/commit" && req.method === "POST") {
        // Giới hạn bảo vệ Worker (gói Free: tối đa 50 lệnh gọi ra ngoài mỗi request, CPU rất ít)
        const maxBody = Number(env.MAX_BODY_BYTES) || 4000000, maxFiles = Number(env.MAX_FILES_PER_COMMIT) || 40;
        const tooBig = { error: `Dữ liệu quá lớn (tối đa ${Math.round(maxBody / 1e6)} MB mỗi lần). Giảm ảnh hoặc đăng từng phần.` };
        if (Number(req.headers.get("Content-Length")) > maxBody) return json(env, tooBig, 413);
        const raw = await req.text();
        if (raw.length > maxBody) return json(env, tooBig, 413);
        const { message, files = [], deletes = [] } = JSON.parse(raw);
        if (files.length + deletes.length > maxFiles) return json(env, { error: `Tối đa ${maxFiles} file mỗi lần commit` }, 413);
        if (Date.now() - lastCommit < 1500) return json(env, { error: "Thao tác quá nhanh, thử lại sau 2 giây" }, 429);
        lastCommit = Date.now();
        if (![...files.map((f) => f.path), ...deletes].every(safePath)) return json(env, { error: "path không hợp lệ" }, 400);
        if (!files.length && !deletes.length) return json(env, { error: "Không có thay đổi" }, 400);
        // Worker giữ sitemap.xml: bài/trang/ảnh thay đổi trong commit này → cập nhật sitemap cùng commit. (sitemap.xml do trang admin bản cũ gửi lên sẽ bị bỏ qua)
        const info = {}, useSm = smRelevant(files, deletes) && files.length + 9 <= (Number(env.SUBREQUEST_LIMIT) || 50);
        const sha = await commitFiles(env, { message: String(message || "Cập nhật từ trang admin").slice(0, 200), files: useSm ? files.filter((f) => f.path !== "sitemap.xml") : files, deletes, edit: useSm ? smEdit(env, files, deletes, info) : undefined });
        return json(env, { ok: true, sha, ...(info.sitemap ? { sitemap: info.sitemap } : {}) });
      }

      if (url.pathname === "/ai/seo" && req.method === "POST") {
        if (!env.AI) return json(env, { error: "Chưa bật Workers AI (binding AI)" }, 501);
        const { title = "", body = "" } = await req.json();
        const messages = [
          { role: "system", content: 'Bạn là chuyên gia SEO tiếng Việt. Chỉ trả về JSON: {"seoTitle":"<=60 ký tự","description":"<=155 ký tự","keywords":["5-10 từ khóa"]}. Không giải thích.' },
          { role: "user", content: `Tiêu đề: ${title}\n\n${String(body).slice(0, 6000)}` },
        ];
        // Cloudflare hay ngừng model cũ → thử lần lượt: model đặt trong AI_MODEL, rồi các model dự phòng. Model nào lỗi/ngừng thì bỏ qua.
        const models = [...new Set([env.AI_MODEL, ...AI_FALLBACKS].filter(Boolean))], errs = [];
        for (const model of models) {
          try {
            const txt = aiText(await env.AI.run(model, { max_tokens: 500, messages })), s0 = txt.indexOf("{"), e0 = txt.lastIndexOf("}");
            if (s0 >= 0 && e0 > s0) { try { return json(env, { ...JSON.parse(txt.slice(s0, e0 + 1)), model }); } catch (e) { /* sai JSON → thử model sau */ } }
            errs.push(`${model}: trả về sai định dạng`);
          } catch (err) { errs.push(`${model}: ${String(err.message || err).slice(0, 140)}`); }
        }
        return json(env, { error: "Không dùng được AI. " + errs.join(" | ") }, 502);
      }

      return json(env, { error: "not found" }, 404);
    } catch (err) {
      // 401 chỉ dành cho phiên admin. Lỗi 401/403 từ GitHub phải đổi sang 502, nếu không trang admin tưởng hết phiên và tự đăng xuất.
      if (err.github && err.status === 401) return json(env, { error: "GitHub từ chối token (401): GITHUB_TOKEN sai, hết hạn hoặc đã bị thu hồi. Tạo token mới (quyền Contents: Read and write cho repo web) rồi đặt lại secret." }, 502);
      if (err.github && err.status === 403) return json(env, { error: `GitHub từ chối quyền (403): token thiếu quyền Contents: Read and write cho repo này, hoặc bị giới hạn tốc độ. ${err.message}` }, 502);
      return json(env, { error: String(err.message || err) }, err.status && err.status >= 400 && err.status < 600 && err.status !== 401 ? err.status : 500);
    }
  },
  async scheduled(event, rawEnv, ctx) {
    const env = cleanEnv(rawEnv);
    // Chỉ còn cron mỗi giờ: kiểm tra mốc lượt xem/tải (không còn quét sitemap định kỳ)
    ctx.waitUntil(checkMilestones(env).catch(() => {}));
  },
};
