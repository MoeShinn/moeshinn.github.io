# Shinju Counter API — Cloudflare Worker (gom lượt, commit hàng loạt)

Hướng dẫn cho người **chưa từng dùng Cloudflare Workers**. Làm đúng thứ tự là chạy.

## Cách hoạt động (đọc 1 phút cho hiểu)

```
Người xem ──(đọc số)──► raw.githubusercontent.com/<repo số liệu>/view-xxx.json   (không qua Worker)

Người xem ──(+1)──► Worker ──► "bộ nhớ đệm" (Durable Object)   trả lời ngay lập tức
                                   │  mỗi 60 giây, NẾU có lượt mới:
                                   ▼
                  đọc hàng loạt 1 lần ──► 1 COMMIT duy nhất sửa tất cả file thay đổi
```

- **Không có lượt xem/tải nào → không có commit nào, không gọi GitHub lần nào.**
- Có lượt mới → chờ tối đa `FLUSH_INTERVAL_SECONDS` (mặc định 60s) rồi ghi **tất cả**
  file thay đổi bằng **đúng 1 commit** (khoảng 4 lệnh gọi API/phút, bất kể 1 hay 100 file).
- Đọc số hiện tại: 1 request GraphQL cho cả lô file. Nếu token của bạn không được phép
  dùng GraphQL, Worker **tự chuyển sang REST** và ghi nhớ trong 30 phút.
- Lượt chờ ghi được lưu bền trong Durable Object → Cloudflare khởi động lại cũng không mất.
- Lỗi GitHub (mạng, rate limit…) → giữ nguyên lượt, thử lại với thời gian chờ tăng dần
  (tối đa 15 phút). Đang gần hết rate limit → tự chờ tới lúc được reset.

**Số liệu luôn lấy lúc commit**: khi ghi, Worker đọc số *đang có trong repo ngay lúc đó* rồi
cộng thêm số lượt đang chờ — không dùng số cũ đã nhớ. Bạn tự sửa số trong repo lúc nào cũng được,
lần commit sau sẽ cộng tiếp từ số bạn sửa (kể cả sửa đúng lúc đang commit, nó đọc lại và làm lại).

**Phía web đọc số**: web đọc thẳng `raw.githubusercontent.com` kèm tham số theo phút
(`...json?t=<số phút>`), nên mỗi phút chỉ có 1 bản cache mới và không bao giờ nhận lại số cũ
hơn ~1 phút từ trình duyệt hay CDN; các lần đọc trong cùng 1 phút dùng chung bản đã tải.

**Lưu ý độ trễ**: số trên web hiển thị chậm hơn thực tế vài phút (tối đa ~1 phút chờ commit,
cộng tối đa ~1 phút của bucket đọc). Bản thân người vừa bấm xem vẫn thấy
số mới ngay vì Worker trả về tổng ước tính ngay lúc đó.

> **Durable Object trên gói Free**: Worker này dùng loại Durable Object lưu bằng SQLite
> (`new_sqlite_classes` trong `wrangler.toml`) — loại dùng được trên gói Free. Hạn mức có thể
> thay đổi theo thời gian, hãy xem mục *Workers & Pages → Durable Objects* trong dashboard
> để biết con số hiện hành. Một blog cá nhân dùng rất ít so với hạn mức.

---

## Bước 0 — Chuẩn bị
- Cài **Node.js** (bản LTS): https://nodejs.org
- Tài khoản Cloudflare (miễn phí): https://dash.cloudflare.com/sign-up

## Bước 1 — Repo số liệu trên GitHub
1. https://github.com/new → tên ví dụ `api-counters`
2. Để **Public** (bắt buộc, vì web đọc qua `raw.githubusercontent.com`)
3. Tick "Add a README file" → **Create repository**

Repo này tự có thêm các file `view-xxx.json`, `download-xxx.json` khi có lượt đầu tiên.

## Bước 2 — Tạo Personal Access Token
1. https://github.com/settings/tokens?type=beta → **Generate new token**
2. **Repository access** → *Only select repositories* → chọn đúng `api-counters`
3. **Permissions → Repository permissions → Contents → Read and write**
4. Generate, **copy token ngay** (chỉ hiện 1 lần)

## Bước 3 — Cài công cụ và đăng nhập
```bash
cd counter-api-cf
npm install
npx wrangler login
```

## Bước 4 — Sửa `wrangler.toml`
```toml
ALLOWED_ORIGIN = "https://moeshinn.github.io"   # domain web thật (không có / ở cuối)
GITHUB_OWNER = "MoeShinn"                        # tài khoản GitHub của bạn
GITHUB_REPO = "api-counters"                # đúng tên repo ở Bước 1
```
Các thông số tuỳ chọn (có thể để nguyên):

| Biến | Mặc định | Ý nghĩa |
|---|---|---|
| `FLUSH_INTERVAL_SECONDS` | 60 | tối đa 1 commit mỗi chừng này giây |
| `MAX_FILES_PER_COMMIT` | 100 | số file tối đa trong 1 commit (dư thì chia thêm lượt) |
| `MIN_HIT_INTERVAL_SECONDS` | 30 | cùng 1 người + cùng 1 bộ đếm trong khoảng này chỉ tính 1 lần |
| `READ_MODE` | auto | `auto` = GraphQL, lỗi thì REST · `graphql` · `rest` |
| `COUNTER_TYPES` | view/download | thêm loại mới, ví dụ `{"view":"views","download":"downloads","like":"likes"}` |

## Bước 5 — Đặt 2 mật khẩu bí mật
```bash
npx wrangler secret put GITHUB_TOKEN
npx wrangler secret put ADMIN_TOKEN
```
- `GITHUB_TOKEN`: dán token ở Bước 2.
- `ADMIN_TOKEN`: tự đặt 1 chuỗi dài bất kỳ (dùng để xem `/status` và gọi `/flush`).

## Bước 6 — Deploy
```bash
npm run deploy
```
Dòng cuối in ra URL dạng `https://n238.git-api.workers.dev` — **lưu lại**.

>>> https://n238.git-api.workers.dev

## Bước 7 — Kiểm thử (làm đúng thứ tự này)

Thay `URL` và `MATKHAU` (chính là `ADMIN_TOKEN`). Dán vào trình duyệt được:

1. `URL/health` → thấy `{"ok":true,...}`
2. `URL/hit/view/test` (bấm 1–2 lần; lần 2 trong 30s sẽ thấy `"counted":false` — đúng thiết kế)
3. `URL/status?token=MATKHAU` → thấy `pendingHits` ≥ 1 và `nextFlushAt` (giờ sắp ghi)
4. `URL/flush?token=MATKHAU` → ép ghi ngay. Kết quả mong muốn:
   `{"ok":true,"files":1,"hits":1,"commit":"...","readMode":"graphql"}`
5. Vào repo `api-counters` → thấy commit `chore(counters): +1 in 1 file(s) [skip ci]` và file `view-test.json`.
6. `URL/status?token=MATKHAU` lần nữa → `lastFlush.ok: true`, `consecutiveFailures: 0`.

**Cách biết đọc hàng loạt có ổn không**: nhìn `readMode` ở bước 4/6.
- `graphql` → token của bạn dùng được GraphQL, mỗi phút chỉ 1 lệnh đọc cho cả lô.
- `rest` → GraphQL bị từ chối (xem lý do ở `lastGraphqlError` trong `/status`); Worker vẫn chạy
  bình thường bằng REST (số lệnh đọc = số file thay đổi trong phút đó, thường rất ít).

Muốn tự thử tải: chỉnh `FLUSH_INTERVAL_SECONDS` rồi `npm run deploy`; theo dõi
`githubRateLimit.remaining` trong `/status` — nếu giữ ổn định gần 5000 là an toàn.

## Bước 8 — Gắn vào website
Mở `post/js/main.js` và `download/js/main.js`, sửa `COUNTER_API_BASE` thành URL ở Bước 6.
Phần đọc số (`raw.githubusercontent.com`) giữ nguyên.

---

## Xử lý lỗi thường gặp

| Hiện tượng | Cách xử lý |
|---|---|
| `'wrangler' is not recognized` | chưa `npm install`, hoặc thiếu chữ `npx` |
| `You must be logged in` | chạy lại `npx wrangler login` |
| `/status` báo `Unauthorized` | sai/thiếu `ADMIN_TOKEN` (header `X-Admin-Token` hoặc `?token=`) |
| `lastFlush.error` chứa `401`/`403` | token sai, hết hạn, hoặc không có quyền *Contents: Read and write* |
| `lastFlush.error` chứa `404` | sai `GITHUB_OWNER`/`GITHUB_REPO`/`GITHUB_BRANCH` trong `wrangler.toml` (nhớ deploy lại) |
| Web luôn hiện 0 | chưa sửa `COUNTER_API_BASE`, hoặc repo số liệu chưa để **Public** |
| CORS error ở Console | `ALLOWED_ORIGIN` chưa khớp domain thật; sửa xong `npm run deploy` |
| Số trên web chậm cập nhật | bình thường — xem mục *Lưu ý độ trễ* ở đầu file |

**UptimeRobot**: không cần — Cloudflare Workers không có cold start/ngủ đông.
