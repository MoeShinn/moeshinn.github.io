/**
 * Shinju counter API — Cloudflare Worker + Durable Object (batched writes).
 *
 * WHY THIS DESIGN (vs. "one GitHub commit per view"):
 *   - Every +1 is only added to a small buffer kept inside ONE Durable
 *     Object (persisted in its own storage, so it survives restarts).
 *   - A timer (DO "alarm") flushes the buffer to GitHub at most once per
 *     FLUSH_INTERVAL_SECONDS (default 60), and ONLY if something is
 *     pending — no views/downloads = no timer = zero GitHub calls.
 *   - A flush writes EVERY changed counter file in ONE git commit
 *     (Git Data API: tree -> commit -> ref), i.e. ~4 API calls per
 *     minute no matter how many files/hits were buffered.
 *   - To get the current numbers it reads the files of that batch ONCE
 *     per flush, in bulk: a single GraphQL request (falls back to REST
 *     automatically if GraphQL is refused for your token).
 *
 * THE NUMBER WRITTEN IS ALWAYS "WHAT THE REPO HOLDS AT COMMIT TIME + WHAT
 * WAS BUFFERED". The value is read from GitHub inside the flush itself
 * (and re-read on every retry); no previously remembered total is ever
 * used to compute it. So if you edit a view/download count by hand in the
 * counters repo, the next commit simply continues from your edited value.
 * (The remembered "v:" totals are only used to give the visitor who just
 * clicked an instant on-screen estimate.)
 *
 * Reading counts on the website is unchanged and never touches this
 * Worker: the frontend reads raw.githubusercontent.com directly.
 *
 * Endpoints:
 *   GET /health                -> { ok: true }
 *   GET /hit/:type/:id         -> buffers +1, answers instantly
 *   GET /status  (admin)       -> buffer size, last flush result, rate limit, ...
 *   GET /flush   (admin)       -> flush right now (for testing)
 *     admin = header "X-Admin-Token: <ADMIN_TOKEN>" (or ?token=<ADMIN_TOKEN>)
 *
 * Files in the counters repo:  <type>-<id>.json  e.g. view-chao-mung.json
 *   -> { "views": 138, "updatedAt": "..." }
 */
import { DurableObject } from "cloudflare:workers";

const GITHUB_API = "https://api.github.com";
const ID_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$/; // ids become file names: no slashes, no ".."

function corsHeaders(env) {
  return {
    "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN || "*",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, X-Admin-Token",
  };
}

function json(data, env, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders(env) },
  });
}

function getCounterTypes(env) {
  try {
    return JSON.parse(env.COUNTER_TYPES || '{"view":"views","download":"downloads"}');
  } catch (e) {
    return { view: "views", download: "downloads" };
  }
}

function b64ToText(b64) {
  const bin = atob(String(b64).replace(/\n/g, ""));
  return new TextDecoder().decode(Uint8Array.from(bin, (c) => c.charCodeAt(0)));
}

/* ================================================================ */
/* Durable Object: the buffer + the batched GitHub writer            */
/* ================================================================ */
export class CounterBuffer extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.flushing = false;
    this.lastHit = new Map(); // "ip|key" -> timestamp (light anti-spam, memory only)
    this.rate = null; // last seen GitHub rate-limit headers
    this.gqlSkipUntil = 0; // after a GraphQL failure, use REST for a while
    this.lastGraphqlError = null;
    this.lastFlush = null;
  }

  /* ---------- config ---------- */
  get interval() {
    return Math.max(10, Number(this.env.FLUSH_INTERVAL_SECONDS) || 60) * 1000;
  }
  get maxFiles() {
    return Math.min(200, Math.max(1, Number(this.env.MAX_FILES_PER_COMMIT) || 100));
  }
  get minHitGap() {
    return Math.max(0, Number(this.env.MIN_HIT_INTERVAL_SECONDS ?? 30)) * 1000;
  }
  get repo() {
    return {
      owner: this.env.GITHUB_OWNER,
      name: this.env.GITHUB_REPO,
      branch: this.env.GITHUB_BRANCH || "main",
    };
  }

  /* ---------- HTTP entry (called by the Worker) ---------- */
  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === "/hit") {
      const { type, id, ip } = await request.json();
      return Response.json(await this.hit(type, id, ip));
    }
    if (url.pathname === "/status") return Response.json(await this.status());
    if (url.pathname === "/flush") return Response.json(await this.flush("manual"));
    return new Response("not found", { status: 404 });
  }

  /* ---------- buffering a hit ---------- */
  async hit(type, id, ip) {
    const key = `${type}:${id}`;
    const base = await this.ctx.storage.get(`v:${key}`); // last value we committed (if known)
    const cur = (await this.ctx.storage.get(`p:${key}`)) || 0;
    const estimate = (n) => (base == null ? null : base + n);

    // Same visitor hammering the same counter -> ignore the repeats.
    const now = Date.now();
    const tk = `${ip || "?"}|${key}`;
    const last = this.lastHit.get(tk);
    if (ip && last && now - last < this.minHitGap) {
      return { counted: false, value: estimate(cur) };
    }
    this.lastHit.set(tk, now);
    if (this.lastHit.size > 5000) this.lastHit.clear();

    await this.ctx.storage.put(`p:${key}`, cur + 1);
    await this.scheduleAlarm(this.interval); // only sets a timer if none is running
    return { counted: true, value: estimate(cur + 1) };
  }

  async scheduleAlarm(ms, force = false) {
    const existing = await this.ctx.storage.getAlarm();
    if (existing == null || force) await this.ctx.storage.setAlarm(Date.now() + ms);
  }

  async hasPending() {
    return (await this.ctx.storage.list({ prefix: "p:", limit: 1 })).size > 0;
  }

  /* ---------- the timer ---------- */
  async alarm() {
    return await this.flush("alarm"); // result is ignored by Cloudflare; returned for tests/logging
  }

  /* ---------- flush: ONE commit for everything pending ---------- */
  async flush(reason = "alarm") {
    if (this.flushing) return { ok: false, skipped: "a flush is already running" };
    this.flushing = true;
    const startedAt = Date.now();
    try {
      const types = getCounterTypes(this.env);
      const items = [];
      for (const [k, n] of await this.ctx.storage.list({ prefix: "p:" })) {
        const key = k.slice(2);
        const i = key.indexOf(":");
        const type = key.slice(0, i);
        const id = key.slice(i + 1);
        if (!types[type]) {
          await this.ctx.storage.delete(k); // type was removed from COUNTER_TYPES -> drop it
          continue;
        }
        if (n > 0) items.push({ key, type, id, field: types[type], n });
      }
      if (!items.length) return { ok: true, files: 0, note: "nothing pending — no GitHub call made" };

      // Respect GitHub's rate limit if we're nearly out.
      if (reason !== "manual" && this.rate && this.rate.remaining <= 5 && this.rate.reset * 1000 > Date.now()) {
        await this.scheduleAlarm(this.rate.reset * 1000 - Date.now() + 1000, true);
        return { ok: false, skipped: "rate limit nearly exhausted, waiting for reset" };
      }

      const batch = items.slice(0, this.maxFiles);
      const out = await this.commitBatch(batch);

      // Success: remove exactly what we committed (hits that arrived meanwhile stay).
      for (const it of batch) {
        const cur = (await this.ctx.storage.get(`p:${it.key}`)) || 0;
        const rest = cur - it.n;
        if (rest > 0) await this.ctx.storage.put(`p:${it.key}`, rest);
        else await this.ctx.storage.delete(`p:${it.key}`);
        await this.ctx.storage.put(`v:${it.key}`, out.values[it.key]);
      }
      await this.ctx.storage.put("meta:failures", 0);

      if (items.length > batch.length) await this.scheduleAlarm(5000);
      else if (await this.hasPending()) await this.scheduleAlarm(this.interval);

      this.lastFlush = {
        ok: true, at: new Date().toISOString(), reason, files: batch.length, hits: out.total,
        commit: out.commitSha, readMode: out.mode, ms: Date.now() - startedAt,
      };
      await this.ctx.storage.put("meta:lastFlush", this.lastFlush);
      return this.lastFlush;
    } catch (e) {
      const failures = ((await this.ctx.storage.get("meta:failures")) || 0) + 1;
      await this.ctx.storage.put("meta:failures", failures);
      const wait = Math.min(this.interval * 2 ** failures, 15 * 60 * 1000); // backoff, max 15 min
      await this.scheduleAlarm(wait, true);
      this.lastFlush = { ok: false, at: new Date().toISOString(), reason, error: String(e.message || e), retryInMs: wait };
      await this.ctx.storage.put("meta:lastFlush", this.lastFlush);
      console.error("flush failed:", this.lastFlush.error);
      return this.lastFlush;
    } finally {
      this.flushing = false;
    }
  }

  async status() {
    const pending = await this.ctx.storage.list({ prefix: "p:" });
    let hits = 0;
    for (const n of pending.values()) hits += n;
    const alarm = await this.ctx.storage.getAlarm();
    return {
      pendingFiles: pending.size,
      pendingHits: hits,
      nextFlushAt: alarm ? new Date(alarm).toISOString() : null,
      flushIntervalSeconds: this.interval / 1000,
      readModeConfig: this.env.READ_MODE || "auto",
      lastFlush: this.lastFlush || (await this.ctx.storage.get("meta:lastFlush")) || null,
      lastGraphqlError: this.lastGraphqlError,
      consecutiveFailures: (await this.ctx.storage.get("meta:failures")) || 0,
      githubRateLimit: this.rate,
    };
  }

  /* ================================================================ */
  /* GitHub helpers                                                    */
  /* ================================================================ */
  async gh(path, opts = {}) {
    const res = await fetch(`${GITHUB_API}${path}`, {
      ...opts,
      headers: {
        Authorization: `Bearer ${this.env.GITHUB_TOKEN}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "shinju-counter-worker",
        ...(opts.headers || {}),
      },
    });
    const remaining = res.headers.get("x-ratelimit-remaining");
    if (remaining != null) {
      this.rate = { remaining: Number(remaining), reset: Number(res.headers.get("x-ratelimit-reset")) || 0 };
    }
    return res;
  }

  async ghJson(method, path, body) {
    const res = await this.gh(path, {
      method,
      headers: body ? { "Content-Type": "application/json" } : {},
      body: body ? JSON.stringify(body) : undefined,
    });
    if (!res.ok) {
      const text = (await res.text()).slice(0, 300);
      const err = new Error(`GitHub ${method} ${path} -> ${res.status} ${text}`);
      err.status = res.status;
      throw err;
    }
    return res.json();
  }

  /* ---- bulk read: ONE GraphQL request for the head commit + every file ---- */
  async readViaGraphql(batch) {
    const { owner, name, branch } = this.repo;
    const vars = { owner, name, qn: `refs/heads/${branch}` };
    let q = "query($owner:String!,$name:String!,$qn:String!";
    batch.forEach((_, i) => (q += `,$e${i}:String!`));
    q += "){repository(owner:$owner,name:$name){ref(qualifiedName:$qn){target{oid ... on Commit{tree{oid}}}}";
    batch.forEach((it, i) => {
      vars[`e${i}`] = `${branch}:${it.type}-${it.id}.json`;
      q += ` f${i}:object(expression:$e${i}){... on Blob{text}}`;
    });
    q += "}}";

    const res = await this.gh("/graphql", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: q, variables: vars }),
    });
    if (!res.ok) throw new Error(`GraphQL HTTP ${res.status} ${(await res.text()).slice(0, 200)}`);
    const data = await res.json();
    if (data.errors && data.errors.length) throw new Error(`GraphQL: ${data.errors[0].message}`);
    const repo = data.data && data.data.repository;
    const target = repo && repo.ref && repo.ref.target;
    if (!target) throw new Error("GraphQL: branch not found");

    const contents = new Map();
    batch.forEach((it, i) => {
      const f = repo[`f${i}`];
      contents.set(`${it.type}-${it.id}.json`, f && typeof f.text === "string" ? f.text : null);
    });
    return { headSha: target.oid, treeSha: target.tree.oid, contents };
  }

  /* ---- fallback: REST (1 + 1 + one call per file) ---- */
  async readViaRest(batch) {
    const { owner, name, branch } = this.repo;
    const ref = await this.ghJson("GET", `/repos/${owner}/${name}/git/ref/heads/${branch}`);
    const headSha = ref.object.sha;
    const commit = await this.ghJson("GET", `/repos/${owner}/${name}/git/commits/${headSha}`);
    const contents = new Map();
    for (let i = 0; i < batch.length; i += 10) {
      await Promise.all(
        batch.slice(i, i + 10).map(async (it) => {
          const path = `${it.type}-${it.id}.json`;
          const res = await this.gh(`/repos/${owner}/${name}/contents/${path}?ref=${encodeURIComponent(branch)}`);
          if (res.status === 404) return contents.set(path, null);
          if (!res.ok) throw new Error(`GitHub GET ${path} -> ${res.status}`);
          contents.set(path, b64ToText((await res.json()).content));
        })
      );
    }
    return { headSha, treeSha: commit.tree.sha, contents };
  }

  async readState(batch) {
    const mode = this.env.READ_MODE || "auto"; // "auto" | "graphql" | "rest"
    const skipGql = mode === "auto" && Date.now() < this.gqlSkipUntil;
    if (mode !== "rest" && !skipGql) {
      try {
        return { ...(await this.readViaGraphql(batch)), mode: "graphql" };
      } catch (e) {
        this.lastGraphqlError = String(e.message || e);
        if (mode === "graphql") throw e;
        this.gqlSkipUntil = Date.now() + 30 * 60 * 1000; // don't waste a call each minute
        console.warn("GraphQL read failed, using REST for 30 min:", this.lastGraphqlError);
      }
    }
    return { ...(await this.readViaRest(batch)), mode: "rest" };
  }

  /* ---- the single batched commit ---- */
  async commitBatch(batch) {
    const { owner, name, branch } = this.repo;
    let lastErr;
    for (let attempt = 0; attempt < 3; attempt++) {
      const state = await this.readState(batch); // fresh head + current numbers every attempt
      const stamp = new Date().toISOString();
      const values = {};
      const entries = [];
      let total = 0;

      for (const it of batch) {
        const path = `${it.type}-${it.id}.json`;
        let obj = {};
        const text = state.contents.get(path);
        if (text) {
          try { obj = JSON.parse(text); } catch (e) { obj = {}; }
        }
        const next = (Number(obj[it.field]) || 0) + it.n; // repo value + what we buffered
        values[it.key] = next;
        total += it.n;
        entries.push({
          path, mode: "100644", type: "blob",
          content: JSON.stringify({ ...obj, [it.field]: next, updatedAt: stamp }, null, 2) + "\n",
        });
      }

      const tree = await this.ghJson("POST", `/repos/${owner}/${name}/git/trees`, {
        base_tree: state.treeSha,
        tree: entries,
      });
      const commit = await this.ghJson("POST", `/repos/${owner}/${name}/git/commits`, {
        message: `chore(counters): +${total} in ${batch.length} file(s) [skip ci]`,
        tree: tree.sha,
        parents: [state.headSha],
      });
      const res = await this.gh(`/repos/${owner}/${name}/git/refs/heads/${branch}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sha: commit.sha, force: false }),
      });
      if (res.ok) return { commitSha: commit.sha, values, total, mode: state.mode };

      if (res.status === 422 || res.status === 409) {
        lastErr = new Error(`branch moved while committing (HTTP ${res.status}), retrying`);
        continue; // somebody pushed in between — re-read and redo
      }
      throw new Error(`update ref -> ${res.status} ${(await res.text()).slice(0, 200)}`);
    }
    throw lastErr || new Error("could not update the branch");
  }
}

/* ================================================================ */
/* Worker (public entry)                                              */
/* ================================================================ */
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, "") || "/";

    if (request.method === "OPTIONS") return new Response(null, { headers: corsHeaders(env) });
    if (path === "/health") return json({ ok: true, counterTypes: Object.keys(getCounterTypes(env)) }, env);

    const stub = env.COUNTER_BUFFER.get(env.COUNTER_BUFFER.idFromName("main")); // ONE global buffer

    if (path === "/status" || path === "/flush") {
      const token = request.headers.get("X-Admin-Token") || url.searchParams.get("token");
      if (!env.ADMIN_TOKEN || token !== env.ADMIN_TOKEN) return json({ error: "Unauthorized" }, env, 401);
      const res = await stub.fetch(`https://counter.internal${path}`);
      return json(await res.json(), env);
    }

    const m = path.match(/^\/hit\/([^/]+)\/([^/]+)$/);
    if (m && request.method === "GET") {
      let type, id;
      try {
        type = decodeURIComponent(m[1]);
        id = decodeURIComponent(m[2]);
      } catch (e) {
        return json({ error: "Bad request" }, env, 400);
      }
      const types = getCounterTypes(env);
      if (!types[type]) {
        return json({ error: `Unknown counter type "${type}". Configured: ${Object.keys(types).join(", ")}` }, env, 400);
      }
      if (!ID_RE.test(id)) return json({ error: "Invalid id" }, env, 400);

      try {
        const res = await stub.fetch("https://counter.internal/hit", {
          method: "POST",
          body: JSON.stringify({ type, id, ip: request.headers.get("CF-Connecting-IP") || "" }),
        });
        const r = await res.json();
        const body = { counted: r.counted, pending: true }; // written to GitHub within ~1 minute
        if (r.value != null) body[types[type]] = r.value; // best-known total incl. this hit
        return json(body, env);
      } catch (e) {
        return json({ error: String(e.message || e) }, env, 500);
      }
    }

    return json({ error: "Not found" }, env, 404);
  },
};
