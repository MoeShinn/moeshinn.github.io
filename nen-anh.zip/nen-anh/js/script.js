// Client-Side Execution Engine
document.addEventListener('DOMContentLoaded', () => {
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const formatSelect = document.getElementById('formatSelect');
    const qualityRange = document.getElementById('qualityRange');
    const qualityVal = document.getElementById('qualityVal');
    const resizeSelect = document.getElementById('resizeSelect');
    const imageList = document.getElementById('imageList');
    const globalActions = document.getElementById('globalActions');
    const statsSummary = document.getElementById('statsSummary');
    const clearBtn = document.getElementById('clearBtn');
    const downloadZipBtn = document.getElementById('downloadZipBtn');

    let processedFiles = [];

    qualityRange.addEventListener('input', (e) => {
        qualityVal.textContent = e.target.value;
        reprocessAllFiles();
    });

    formatSelect.addEventListener('change', reprocessAllFiles);
    resizeSelect.addEventListener('change', reprocessAllFiles);

    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropZone.classList.add('drag-over');
        }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropZone.classList.remove('drag-over');
        }, false);
    });

    dropZone.addEventListener('drop', (e) => {
        const dt = e.dataTransfer;
        handleFiles(dt.files);
    });

    fileInput.addEventListener('change', (e) => {
        handleFiles(e.target.files);
    });

    function handleFiles(files) {
        const validFiles = Array.from(files).filter(file => file.type.startsWith('image/'));
        if (validFiles.length === 0) return;

        validFiles.forEach(file => {
            const fileObj = {
                id: Math.random().toString(36).substring(2, 9),
                file: file,
                originalSize: file.size,
                compressedBlob: null,
                compressedUrl: null,
                compressedSize: 0
            };
            processedFiles.push(fileObj);
            processImage(fileObj);
        });

        updateUI();
    }

    function processImage(fileObj) {
        const reader = new FileReader();
        reader.readAsDataURL(fileObj.file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target.result;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');

                const scale = parseFloat(resizeSelect.value);
                const targetWidth = Math.round(img.width * scale);
                const targetHeight = Math.round(img.height * scale);

                canvas.width = targetWidth;
                canvas.height = targetHeight;

                ctx.drawImage(img, 0, 0, targetWidth, targetHeight);

                const mimeType = formatSelect.value;
                const quality = parseInt(qualityRange.value, 10) / 100;

                canvas.toBlob((blob) => {
                    if (fileObj.compressedUrl) {
                        URL.revokeObjectURL(fileObj.compressedUrl);
                    }
                    fileObj.compressedBlob = blob;
                    fileObj.compressedSize = blob.size;
                    fileObj.compressedUrl = URL.createObjectURL(blob);

                    renderImageCard(fileObj);
                    updateStats();
                }, mimeType, quality);
            };
        };
    }

    function reprocessAllFiles() {
        processedFiles.forEach(fileObj => {
            processImage(fileObj);
        });
    }

    function renderImageCard(fileObj) {
        let card = document.getElementById(`card-${fileObj.id}`);
        const ext = getExtension(formatSelect.value);
        const newFileName = fileObj.file.name.replace(/\.[^/.]+$/, "") + `_compressed.${ext}`;

        const savingPercent = Math.round(((fileObj.originalSize - fileObj.compressedSize) / fileObj.originalSize) * 100);
        const savingText = savingPercent > 0 ? `Giảm ${savingPercent}%` : `Tăng +${Math.abs(savingPercent)}%`;

        if (!card) {
            card = document.createElement('div');
            card.id = `card-${fileObj.id}`;
            card.className = 'image-card';
            imageList.appendChild(card);
        }

        card.innerHTML = `
            <div class="thumb-container">
                <img src="${fileObj.compressedUrl}" alt="Preview">
            </div>
            <div class="info-container">
                <div class="file-name">${newFileName}</div>
                <div class="size-details">
                    Gốc: ${formatBytes(fileObj.originalSize)} &rarr; Sau nén: <strong>${formatBytes(fileObj.compressedSize)}</strong>
                    <span class="badge badge-saving">${savingText}</span>
                </div>
            </div>
            <a href="${fileObj.compressedUrl}" download="${newFileName}" class="btn btn-primary" style="text-decoration:none; font-size:0.85rem;">Tải Về</a>
        `;
    }

    function updateStats() {
        const totalOriginal = processedFiles.reduce((acc, curr) => acc + curr.originalSize, 0);
        const totalCompressed = processedFiles.reduce((acc, curr) => acc + curr.compressedSize, 0);
        const totalSaving = Math.round(((totalOriginal - totalCompressed) / (totalOriginal || 1)) * 100);

        statsSummary.innerHTML = `Đã xử lý <strong>${processedFiles.length}</strong> tệp • Tiết kiệm dung lượng: <strong>${totalSaving > 0 ? totalSaving : 0}%</strong> (${formatBytes(totalOriginal)} &rarr; ${formatBytes(totalCompressed)})`;
    }

    function updateUI() {
        if (processedFiles.length > 0) {
            globalActions.classList.remove('hidden');
        } else {
            globalActions.classList.add('hidden');
            imageList.innerHTML = '';
        }
    }

    downloadZipBtn.addEventListener('click', () => {
        if (processedFiles.length === 0) return;

        const zip = new JSZip();
        const ext = getExtension(formatSelect.value);

        processedFiles.forEach((fileObj, index) => {
            const fileName = fileObj.file.name.replace(/\.[^/.]+$/, "") + `_${index + 1}.${ext}`;
            zip.file(fileName, fileObj.compressedBlob);
        });

        downloadZipBtn.textContent = 'Đang đóng gói ZIP...';
        downloadZipBtn.disabled = true;

        zip.generateAsync({ type: 'blob' }).then((content) => {
            const zipUrl = URL.createObjectURL(content);
            const link = document.createElement('a');
            link.href = zipUrl;
            link.download = `SpeedCompress_Batch_${Date.now()}.zip`;
            link.click();
            URL.revokeObjectURL(zipUrl);

            downloadZipBtn.textContent = 'Tải Tất Cả (.ZIP)';
            downloadZipBtn.disabled = false;
        });
    });

    clearBtn.addEventListener('click', () => {
        processedFiles.forEach(fileObj => {
            if (fileObj.compressedUrl) URL.revokeObjectURL(fileObj.compressedUrl);
        });
        processedFiles = [];
        updateUI();
    });

    function formatBytes(bytes, decimals = 2) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }

    function getExtension(mimeType) {
        switch (mimeType) {
            case 'image/webp': return 'webp';
            case 'image/jpeg': return 'jpg';
            case 'image/png': return 'png';
            default: return 'jpg';
        }
    }
});
